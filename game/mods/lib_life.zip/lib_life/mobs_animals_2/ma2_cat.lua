--###################
--################### OCELOT - CAT
--###################

mobs:register_mob("mobs_animals_2:cat", {
	type = "animal",
	passive = true,
    runaway = true,
    stepheight = 1.2,
	hp_min = 30,
	hp_max = 60,
	armor = 150,
    collisionbox = {-0.35, -0.01, -0.35, 0.35, 2, 0.35},
    rotate = -180,
	visual = "mesh",
	mesh = "ma2_cat.b3d",
    textures = {{"ma2_cat.png"},{"ma2_cat1.png"},{"ma2_cat2.png"},{"ma2_cat3.png"},{"ma2_cat4.png"}},
	visual_size = {x=3, y=3},
	walk_velocity = 0.6,
	run_velocity = 2,
	jump = true,
	animation = {
		speed_normal = 25,		speed_run = 50,
		stand_start = 0,		stand_end = 0,
		walk_start = 0,		walk_end = 40,
		run_start = 0,		run_end = 40,
	},
})


