getmeta={inv="",user="", }

minetest.register_on_punchnode(function(pos, node, puncher, pointed_thing)
	if getmeta.user=="" or getmeta.user~=puncher:get_player_name() then return end
	if getmeta.inv=="" then return end
	local m=minetest.get_meta(pos):to_table()
	print(node.name,dump(m))
	if m and m.inventory and m.inventory[getmeta.inv] then
		print("inventory " .. getmeta.inv ..":")
		for i, v in pairs(m.inventory[getmeta.inv]) do
			if v:get_name()~="" then
				print(i,v:get_name() .. " "  .. v:get_count())
			end
		end
	end
end)

minetest.register_chatcommand("getitemmeta", {
	params = "",
	description = "Get item meta",
	privs = {server=true},
	func = function(name, param)
		local u=minetest.get_player_by_name(name)
		if not u then return end

		local it=u:get_inventory():get_stack("main", u:get_wield_index())
		local it2=it:to_table()
		print(it:get_name(),dump(it2))
		if not it2 then return end
		if it2.meta then
			print("meta",dump(minetest.deserialize(it2.meta)))
		end
		if it2.metadata then
			print("metadata",dump(minetest.deserialize(it2.metadata)))
		end
	end
})

minetest.register_chatcommand("getnodemeta", {
	params = "",
	description = "Get node meta",
	privs = {server=true},
	func = function(name, param)
		if param=="" then
			getmeta={inv="",user="", }
		else
			getmeta.inv=param
			getmeta.user=name
		end
	end
})