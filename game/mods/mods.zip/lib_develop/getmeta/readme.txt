﻿By AiTechEye
Version: 1
License: CC0

Default required privilege: server

Get meta from nodes and items

Type /getnodemeta <something> and punch nodes to print the meta on the console.
F that <something> is a name of a inventory, then will also output the content too.
Type /getnodemeta without adds to end the outputing

Type /getitemmeta to see the meta from the item in your hand.

This mod is usefull when looking for erros and explore how stuff works.