--Welcome to NodeExplorer init.lua, an important file!
lib_node_explorer = {}
--start registering things
minetest.register_on_punchnode(function(pos, node, puncher, pointed_thing)
		--try to understand the node (they seem to talk chinese)
		local node = minetest.get_node_or_nil(pointed_thing.under)
		local name = node.name
		--send what we know from the lolling node
		local id1 = puncher:hud_add({
			hud_elem_type = "image",
			position = {x = 0.5, y = 0.02},
			scale = {
				x = -26,
				y = -12
			},
		text = "NodeExplorer_HUD.png",
		})
		local id2 = puncher:hud_add({
			hud_elem_type = "text",
			position = {x = 0.5, y = 0.03},
			scale = {
				x = -100,
				y = -100
			},
		text = "  You have touched: \n''" .. name .. "''."
		})
		--then remove it
	minetest.after(1.1, function(name)
	puncher:hud_remove(id1)
	puncher:hud_remove(id2)
	end)	
end)

