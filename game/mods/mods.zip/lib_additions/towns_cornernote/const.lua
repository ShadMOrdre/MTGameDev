--
-- switch for debugging
--
towns_cornernote.debug = false
--
-- material to replace cobblestone with
--
towns_cornernote_wallmaterial = {
  "default:cobble", 
  "default:desert_cobble", 
  "default:mossycobble"
}
--
-- path to schematics
--
towns_cornernote_schem_path = towns_cornernote.modpath.."/schematics/"
--
-- list of schematics
--  {name = "townhall", mts = towns_cornernote_schem_path.."townhall.mts", hsize = 15, max_num = 0, rplc = "n"},
--  {name = "well", mts = towns_cornernote_schem_path.."well.mts", hsize = 11, max_num = 0.045, rplc = "n"},
--  {name = "hut", mts = towns_cornernote_schem_path.."hut.mts", hsize = 11, max_num = 0.9, rplc = "y"},
--  {name = "garden", mts = towns_cornernote_schem_path.."garden.mts", hsize = 11, max_num = 0.1, rplc = "n"},
--  {name = "lamp", mts = towns_cornernote_schem_path.."lamp.mts", hsize = 10, max_num = 0.1, rplc = "n"},
--  {name = "tower", mts = towns_cornernote_schem_path.."tower.mts", hsize = 11, max_num = 0.055, rplc = "n"},
--  {name = "church", mts = towns_cornernote_schem_path.."church.mts", hsize = 17, max_num = 0.050, rplc = "n"},
--  {name = "blacksmith", mts = towns_cornernote_schem_path.."blacksmith.mts", hsize = 11, max_num = 0.050, rplc = "n"},
--
--[[
--]]
--
towns_cornernote_schematic_table = { 
  {name = "mgs_tower_new_02_10w_8l_17h_0_90", mts = towns_cornernote_schem_path.."mgs_tower_new_02_10w_8l_17h_0_90.mts", hsize = 14, max_num = 0, rplc = "n"},
  {name = "settlements_townhall", mts = towns_cornernote_schem_path.."settlements_townhall.mts", hsize = 15, max_num = 0.050, rplc = "n"},
  {name = "settlements_well", mts = towns_cornernote_schem_path.."settlements_well.mts", hsize = 11, max_num = 0.045, rplc = "n"},
  {name = "mgs_mine_new_02_13w_9l_31h_0_270", mts = towns_cornernote_schem_path.."mgs_mine_new_02_13w_9l_31h_0_270.mts", hsize = 25, max_num = 0.050, rplc = "n"},
  {name = "settlements_hut", mts = towns_cornernote_schem_path.."settlements_hut.mts", hsize = 11, max_num = 0.9, rplc = "y"},
  {name = "settlements_garden", mts = towns_cornernote_schem_path.."settlements_garden.mts", hsize = 11, max_num = 0.1, rplc = "n"},
  {name = "settlements_lamp", mts = towns_cornernote_schem_path.."settlements_lamp.mts", hsize = 10, max_num = 0.1, rplc = "n"},
  {name = "settlements_tower", mts = towns_cornernote_schem_path.."settlements_tower.mts", hsize = 11, max_num = 0.055, rplc = "n"},
  {name = "settlements_church", mts = towns_cornernote_schem_path.."settlements_church.mts", hsize = 17, max_num = 0.050, rplc = "n"},
  {name = "settlements_blacksmith", mts = towns_cornernote_schem_path.."settlements_blacksmith.mts", hsize = 11, max_num = 0.050, rplc = "n"},
  {name = "mgs_turret_new_01_6w_6l_9h_0_90", mts = towns_cornernote_schem_path.."mgs_turret_new_01_6w_6l_9h_0_90.mts", hsize = 10, max_num = 0.075, rplc = "n"},
}
towns_cornernote_schematic_table2 = { 
  {name = "bldg_fortress_x25_y22_z23_r90", mts = towns_cornernote.schem_bldg_fortress_x25_y22_z23_r90, hsize = 27, max_num = 0, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_chapel_x22_y21_z13_r000", mts = towns_cornernote.schem_bldg_chapel_x22_y21_z13_r000, hsize = 27, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_lavabeacon_x9_y24_z9_r90", mts = towns_cornernote.schem_bldg_lavabeacon_x9_y24_z9_r90, hsize = 13, max_num = 0.050, rplc = "n", rot = "-1", off = 1},
  {name = "bldg_well_x6_y9_z6_r000", mts = towns_cornernote.schem_bldg_well_x6_y9_z6_r000, hsize = 10, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_hut_x7_y8_z7_r180", mts = towns_cornernote.schem_bldg_hut_x7_y8_z7_r180, hsize = 11, max_num = 0.075, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_forge_x8_y9_z9_r270", mts = towns_cornernote.schem_bldg_forge_x8_y9_z9_r270, hsize = 12, max_num = 0.035, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_mine_x11_y29_z9_r180", mts = towns_cornernote.schem_bldg_mine_x11_y29_z9_r180, hsize = 15, max_num = 0.035, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_turret_x6_y9_z6_r180", mts = towns_cornernote.schem_bldg_turret_x6_y9_z6_r180, hsize = 10, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_tower_x9_y15_z8_r180", mts = towns_cornernote.schem_bldg_tower_x9_y15_z8_r180, hsize = 13, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
}
--[[
  {name = "bldg_castle_x27_y16_z33_r90", mts = towns_cornernote.schem_bldg_castle_x27_y15_z33_r90, hsize = 40, max_num = 0, rplc = "n", rot = "90", off = 0},
--]]
--
-- baseplate material, to replace dirt with grass and where buildings can be built
--
towns_cornernote_surface_mat = {
 	"lib_materials:dirt_with_grass_warm_humid_lowland",
 	--"lib_materials:dirt_with_grass_warm_humid_coastal",
 	--"lib_materials:dirt_with_grass_warm_semihumid_coastal",
 	--"lib_materials:dirt_with_grass_warm_temperate_coastal",

}
--
-- temporary info for currentliy built settlement (position of each building) 
--
towns_cornernote_settlement_info = {}
--
-- list of towns_cornernote, load on server start up
--
towns_cornernote_settled_areas_in_world = {}
--
-- min_distance between towns_cornernote
--
min_dist_towns_cornernote = 1000
if towns_cornernote.debug == true 
then
  min_dist_towns_cornernote = 200
end
--
-- maximum allowed difference in height for building a sttlement
--
towns_cornernote_max_height_difference = 3
--
--
--
towns_cornernote_half_map_chunk_size = 40
towns_cornernote_quarter_map_chunk_size = 20
