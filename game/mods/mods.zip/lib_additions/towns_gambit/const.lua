--
-- switch for debugging
--
towns_gambit.debug = false
--
-- material to replace cobblestone with
--
towns_gambit_wallmaterial = {
  "default:cobble", 
  "default:desert_cobble", 
  "default:mossycobble"
}
--
-- path to schematics
--
towns_gambit_schem_path = towns_gambit.modpath.."/schematics/"
--
-- list of schematics
--  {name = "townhall", mts = towns_gambit_schem_path.."townhall.mts", hsize = 15, max_num = 0, rplc = "n"},
--  {name = "well", mts = towns_gambit_schem_path.."well.mts", hsize = 11, max_num = 0.045, rplc = "n"},
--  {name = "hut", mts = towns_gambit_schem_path.."hut.mts", hsize = 11, max_num = 0.9, rplc = "y"},
--  {name = "garden", mts = towns_gambit_schem_path.."garden.mts", hsize = 11, max_num = 0.1, rplc = "n"},
--  {name = "lamp", mts = towns_gambit_schem_path.."lamp.mts", hsize = 10, max_num = 0.1, rplc = "n"},
--  {name = "tower", mts = towns_gambit_schem_path.."tower.mts", hsize = 11, max_num = 0.055, rplc = "n"},
--  {name = "church", mts = towns_gambit_schem_path.."church.mts", hsize = 17, max_num = 0.050, rplc = "n"},
--  {name = "blacksmith", mts = towns_gambit_schem_path.."blacksmith.mts", hsize = 11, max_num = 0.050, rplc = "n"},
--
--[[
--]]
--
towns_gambit_schematic_table = { 
  {name = "mgs_tower_new_02_10w_8l_17h_0_90", mts = towns_gambit_schem_path.."mgs_tower_new_02_10w_8l_17h_0_90.mts", hsize = 14, max_num = 0, rplc = "n"},
  {name = "settlements_townhall", mts = towns_gambit_schem_path.."settlements_townhall.mts", hsize = 15, max_num = 0.050, rplc = "n"},
  {name = "settlements_well", mts = towns_gambit_schem_path.."settlements_well.mts", hsize = 11, max_num = 0.045, rplc = "n"},
  {name = "mgs_mine_new_02_13w_9l_31h_0_270", mts = towns_gambit_schem_path.."mgs_mine_new_02_13w_9l_31h_0_270.mts", hsize = 25, max_num = 0.050, rplc = "n"},
  {name = "settlements_hut", mts = towns_gambit_schem_path.."settlements_hut.mts", hsize = 11, max_num = 0.9, rplc = "y"},
  {name = "settlements_garden", mts = towns_gambit_schem_path.."settlements_garden.mts", hsize = 11, max_num = 0.1, rplc = "n"},
  {name = "settlements_lamp", mts = towns_gambit_schem_path.."settlements_lamp.mts", hsize = 10, max_num = 0.1, rplc = "n"},
  {name = "settlements_tower", mts = towns_gambit_schem_path.."settlements_tower.mts", hsize = 11, max_num = 0.055, rplc = "n"},
  {name = "settlements_church", mts = towns_gambit_schem_path.."settlements_church.mts", hsize = 17, max_num = 0.050, rplc = "n"},
  {name = "settlements_blacksmith", mts = towns_gambit_schem_path.."settlements_blacksmith.mts", hsize = 11, max_num = 0.050, rplc = "n"},
  {name = "mgs_turret_new_01_6w_6l_9h_0_90", mts = towns_gambit_schem_path.."mgs_turret_new_01_6w_6l_9h_0_90.mts", hsize = 10, max_num = 0.075, rplc = "n"},
}
towns_gambit_schematic_table2 = { 
  {name = "bldg_fortress_x25_y22_z23_r90", mts = towns_gambit.schem_bldg_fortress_x25_y22_z23_r90, hsize = 32, max_num = 0.0, rplc = "n", rot = "-1", off = 0},
  {name = "gambit_church_x16_y9_z11_180", mts = towns_gambit.schem_gambit_church_x16_y9_z11_180, hsize = 20, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "gambit_library_hotel_x12_y9_z18_180", mts = towns_gambit.schem_gambit_library_hotel_x12_y9_z18_180, hsize = 22, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "gambit_pub_x10_y6_z13_0", mts = towns_gambit.schem_gambit_pub_x10_y6_z13_0, hsize = 17, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "gambit_forge_x10_y7_z7_270", mts = towns_gambit.schem_gambit_forge_x10_y7_z7_270, hsize = 14, max_num = 0.025, rplc = "n", rot = "-1", off = -1},
  {name = "gambit_shop_x10_y6_z10_90", mts = towns_gambit.schem_gambit_shop_x10_y6_z10_90, hsize = 14, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "gambit_shop_large_x12_y8_z16_0", mts = towns_gambit.schem_gambit_shop_large_x12_y8_z16_0, hsize = 19, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "gambit_stable_x19_y9_z9_90", mts = towns_gambit.schem_gambit_stable_x19_y9_z9_90, hsize = 23, max_num = 0.025, rplc = "n", rot = "-1", off = -1},
  {name = "gambit_tower_x7_y23_z7_270", mts = towns_gambit.schem_gambit_tower_x7_y23_z7_270, hsize = 11, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "gambit_house_x9_y7_z11_0", mts = towns_gambit.schem_gambit_house_x9_y7_z11_0, hsize = 15, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "gambit_field_x7_y3_z7_90", mts = towns_gambit.schem_gambit_field_x7_y3_z7_90, hsize = 11, max_num = 0.025, rplc = "n", rot = "-1", off = -1},
  {name = "gambit_fountain_x5_y5_z5_90", mts = towns_gambit.schem_gambit_fountain_x5_y5_z5_90, hsize = 9, max_num = 0.025, rplc = "n", rot = "-1", off = -1},
  {name = "gambit_lamp_x3_y4_z3_270", mts = towns_gambit.schem_gambit_lamp_x3_y4_z3_270, hsize = 7, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "gambit_shed_open_chests_x5_y5_z5_0", mts = towns_gambit.schem_gambit_shed_open_chests_x5_y5_z5_0, hsize = 9, max_num = 0.025, rplc = "n", rot = "-1", off = -1},
  {name = "gambit_cemetary_x15_y4_z11_180", mts = towns_gambit.schem_gambit_cemetary_x15_y4_z11_180, hsize = 19, max_num = 0.025, rplc = "n", rot = "-1", off = -1},
 }
--[[
  {name = "bldg_church_stone_x11_y16_z20_r000", mts = towns_gambit.schem_bldg_church_stone_x11_y16_z20_r000, hsize = 25, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_settlements_townhall_x10_y12_z11_r000", mts = towns_gambit.schem_bldg_settlements_townhall_x10_y12_z11_r000, hsize = 15, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_lavabeacon_x9_y24_z9_r90", mts = towns_gambit.schem_bldg_lavabeacon_x9_y24_z9_r90, hsize = 13, max_num = 0.025, rplc = "n", rot = "-1", off = 1},
  {name = "bldg_settlements_well_x5_y5_z5_r000", mts = towns_gambit.schem_bldg_settlements_well_x5_y5_z5_r000, hsize = 9, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_settlements_lamp_x3_y7_z3_r000", mts = towns_gambit.schem_bldg_settlements_lamp_x3_y7_z3_r000, hsize = 7, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_village_farm_01_x9_y3_z13_r000", mts = towns_gambit.schem_bldg_village_farm_01_x9_y3_z13_r000, hsize = 19, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_village_05_x15_y13_z9_r000", mts = towns_gambit.schem_bldg_village_05_x15_y13_z9_r000, hsize = 19, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_village_06_x15_y13_z13_r000", mts = towns_gambit.schem_bldg_village_06_x15_y13_z13_r000, hsize = 19, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_village_07_x15_y13_z15_r000", mts = towns_gambit.schem_bldg_village_07_x15_y13_z15_r000, hsize = 19, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_hut_x7_y8_z7_r180", mts = towns_gambit.schem_bldg_hut_x7_y8_z7_r180, hsize = 11, max_num = 0.065, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_forge_x8_y9_z9_r270", mts = towns_gambit.schem_bldg_forge_x8_y9_z9_r270, hsize = 12, max_num = 0.035, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_mine_x11_y29_z9_r180", mts = towns_gambit.schem_bldg_mine_x11_y29_z9_r180, hsize = 15, max_num = 0.035, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_turret_x6_y9_z6_r180", mts = towns_gambit.schem_bldg_turret_x6_y9_z6_r180, hsize = 10, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_tower_x9_y15_z8_r180", mts = towns_gambit.schem_bldg_tower_x9_y15_z8_r180, hsize = 13, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_big1_x6_y7_z6_r000", mts = towns_gambit.tent_big1_x6_y7_z6_r000, hsize = 10, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_big2_x6_y6_z6_r000", mts = towns_gambit.tent_big2_x6_y6_z6_r000, hsize = 10, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_medium1_x5_y5_z5_r000", mts = towns_gambit.tent_medium1_x5_y5_z5_r000, hsize = 9, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_medium2_x5_y4_z5_r000", mts = towns_gambit.tent_medium2_x5_y4_z5_r000, hsize = 9, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_medium3_x5_y5_z5_r000", mts = towns_gambit.tent_medium3_x5_y5_z5_r000, hsize = 9, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_medium4_x5_y5_z5_r000", mts = towns_gambit.tent_medium4_x5_y5_z5_r000, hsize = 9, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_open1_big_x6_y6_z6_r000", mts = towns_gambit.tent_open1_big_x6_y6_z6_r000, hsize = 10, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_open2_big_x6_y6_z6_r000", mts = towns_gambit.tent_open2_big_x6_y6_z6_r000, hsize = 10, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_open3_big_x6_y6_z6_r000", mts = towns_gambit.tent_open3_big_x6_y6_z6_r000, hsize = 10, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_open1_x5_y5_z5_r000", mts = towns_gambit.tent_open1_x5_y5_z5_r000, hsize = 9, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_open2_x5_y4_z5_r000", mts = towns_gambit.tent_open2_x5_y4_z5_r000, hsize = 9, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_open3_x5_y5_z5_r000", mts = towns_gambit.tent_open3_x5_y5_z5_r000, hsize = 9, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_tiny1_x3_y6_z7_r000", mts = towns_gambit.tent_tiny1_x3_y6_z7_r000, hsize = 11, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "tent_tiny2_x3_y5_z4_r000", mts = towns_gambit.tent_tiny2_x3_y5_z4_r000, hsize = 8, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
  {name = "ruin_bunker_x6_y4_z4_r000", mts = towns_gambit.schem_ruin_bunker_x6_y4_z4_r000, hsize = 10, max_num = 0.035, rplc = "n", rot = "-1", off = 0},
  {name = "ruin_cabin_x5_y6_z9_r000", mts = towns_gambit.schem_ruin_cabin_x5_y6_z9_r000, hsize = 13, max_num = 0.035, rplc = "n", rot = "-1", off = 0},
  {name = "ruin_church_x10_y18_z18_r000", mts = towns_gambit.schem_ruin_church_x10_y18_z18_r000, hsize = 22, max_num = 0.035, rplc = "n", rot = "-1", off = 0},
  {name = "ruin_watchtower_x4_y10_z4_r000", mts = towns_gambit.schem_ruin_watchtower_x4_y10_z4_r000, hsize = 8, max_num = 0.035, rplc = "n", rot = "-1", off = 0},
  {name = "ruin_wooden_house_x8_y5_z6_r000", mts = towns_gambit.schem_ruin_wooden_house_x8_y5_z6_r000, hsize = 12, max_num = 0.035, rplc = "n", rot = "-1", off = 0},

  {name = "bldg_village_03_x13_y8_z7_r000", mts = towns_gambit.schem_bldg_village_03_x13_y8_z7_r000, hsize = 17, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
  {name = "bldg_village_04_x19_y13_z14_r000", mts = towns_gambit.schem_bldg_village_04_x19_y13_z14_r000, hsize = 23, max_num = 0.050, rplc = "n", rot = "-1", off = 0},
--  {name = "bldg_castle_x27_y16_z33_r90", mts = towns_gambit.schem_bldg_castle_x27_y15_z33_r90, hsize = 40, max_num = 0, rplc = "n", rot = "90", off = 0},
--  {name = "bldg_fortress_x25_y22_z23_r90", mts = towns_gambit.schem_bldg_fortress_x25_y22_z23_r90, hsize = 27, max_num = 0.025, rplc = "n", rot = "-1", off = 0},
--]]
--
-- baseplate material, to replace dirt with grass and where buildings can be built
--
towns_gambit_surface_mat = {
 	"lib_materials:dirt_with_grass_warm_humid_coastal",
 	--"lib_materials:dirt_with_grass_warm_humid_lowland",
 	--"lib_materials:dirt_with_grass_warm_semihumid_lowland",
 	--"lib_materials:dirt_with_grass_warm_temperate_lowland",

}
--
-- temporary info for currentliy built settlement (position of each building) 
--
towns_gambit_settlement_info = {}
--
-- list of towns_gambit, load on server start up
--
towns_gambit_settled_areas_in_world = {}
--
-- min_distance between towns_gambit
--
min_dist_towns_gambit = 1000
if towns_gambit.debug == true 
then
  min_dist_towns_gambit = 200
end
--
-- maximum allowed difference in height for building a sttlement
--
towns_gambit_max_height_difference = 6
--
--
--
towns_gambit_half_map_chunk_size = 40
towns_gambit_quarter_map_chunk_size = 20
