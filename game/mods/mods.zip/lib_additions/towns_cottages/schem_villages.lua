

--Air, Lava, and Water constants used throughout schematics
		local __ = {name = "air", param2 = 0, prob = 0}
		local wt = {name = "default:river_water_source", param2 = 0, prob = 254}
		local lv = {name = "default:lava_source", param2 = 0, prob = 254}
		local lf = {name = "default:lava_flowing", param2 = 0, prob = 254}
		
--Node Definitions
		local M0 = {name = "lib_materials:stone", param2 = 0, prob = 254}
		local M1 = {name = "lib_materials:stone_cobble", param2 = 0, prob = 254}
		local M2 = {name = "lib_materials:stone_brick", param2 = 0, prob = 254}
		local M3 = {name = "lib_materials:stone_block", param2 = 0, prob = 254}
		local M4 = {name = "lib_materials:stone_stucco", param2 = 0, prob = 254}
		local M5 = {name = "stairs:slab_stonebrick", param2 = 3, prob = 254}
		local M6 = {name = "stairs:stair_cobble", param2 = 0, prob = 254}
		local M7 = {name = "stairs:slab_stonebrick", param2 = 0, prob = 254}
		local M8 = {name = "", param2 = 0, prob = 254}
		local M9 = {name = "", param2 = 0, prob = 254}
		local MX = {name = "", param2 = 4, prob = 254}
		local MZ = {name = "", param2 = 8, prob = 254}

		local N0 = {name = "lib_materials:stone_sand", param2 = 0, prob = 254}
		local N1 = {name = "lib_materials:sand", param2 = 0, prob = 254}
		local N2 = {name = "lib_materials:stone_gravel", param2 = 0, prob = 254}
		local N3 = {name = "lib_materials:stone_cobble_mossy", param2 = 0, prob = 254}
		local N4 = {name = "lib_materials:stone_brick_mossy", param2 = 0, prob = 254}
		local N5 = {name = "lib_materials:stone_tile", param2 = 0, prob = 254}
		local N6 = {name = "lib_materials:stone_tile_with_dirt", param2 = 0, prob = 254}
		local N7 = {name = "lib_materials:stone_tile_mossy", param2 = 0, prob = 254}
		local N8 = {name = "lib_materials:stone_tile_crumbled", param2 = 0, prob = 254}
		local N9 = {name = "default:wood", param2 = 0, prob = 254}
		local NY = {name = "default:tree", param2 = 0, prob = 254}
		local NZ = {name = "default:tree", param2 = 4, prob = 254}
		local NX = {name = "default:tree", param2 = 8, prob = 254}

		local S0 = {name = "stairs:stair_stonebrick", param2 = 0, prob = 254}
		local S1 = {name = "stairs:stair_stonebrick", param2 = 1, prob = 254}
		local S2 = {name = "stairs:stair_stonebrick", param2 = 2, prob = 254}
		local S3 = {name = "stairs:stair_stonebrick", param2 = 3, prob = 254}
		local S4 = {name = "stairs:stair_stonebrick", param2 = 20, prob = 254}
		local S6 = {name = "stairs:stair_stonebrick", param2 = 21, prob = 254}
		local S7 = {name = "stairs:stair_stonebrick", param2 = 22, prob = 254}
		local S8 = {name = "stairs:stair_stonebrick", param2 = 23, prob = 254}
		local SN = {name = "stairs:stair_stonebrick", param2 = 4, prob = 254}
		local SE = {name = "stairs:stair_stonebrick", param2 = 8, prob = 254}
		local SW = {name = "stairs:stair_stonebrick", param2 = 12, prob = 254}
		local SS = {name = "stairs:stair_stonebrick", param2 = 16, prob = 254}
		
		local Q0 = {name = "stairs:slab_wood", param2 = 0, prob = 254}
		local Q1 = {name = "stairs:slab_wood", param2 = 1, prob = 254}
		local Q2 = {name = "stairs:slab_wood", param2 = 2, prob = 254}
		local Q3 = {name = "stairs:slab_wood", param2 = 3, prob = 254}
		local Q4 = {name = "stairs:slab_wood", param2 = 3, prob = 254}
		local Q5 = {name = "stairs:slab_wood", param2 = 20, prob = 254}
		local Q6 = {name = "stairs:slab_wood", param2 = 21, prob = 254}
		local Q7 = {name = "stairs:slab_wood", param2 = 22, prob = 254}
		local Q8 = {name = "stairs:slab_wood", param2 = 23, prob = 254}
		local QN = {name = "stairs:slab_wood", param2 = 4, prob = 254}
		local QE = {name = "stairs:slab_wood", param2 = 8, prob = 254}
		local QW = {name = "stairs:slab_wood", param2 = 12, prob = 254}
		local QS = {name = "stairs:slab_wood", param2 = 16, prob = 254}
		
		local O0 = {name = "stairs:stair_outer_stone", param2 = 0, prob = 254}
		local O1 = {name = "stairs:stair_outer_stone", param2 = 1, prob = 254}
		local O2 = {name = "stairs:stair_outer_stone", param2 = 2, prob = 254}
		local O3 = {name = "stairs:stair_outer_stone", param2 = 3, prob = 254}
		local O5 = {name = "stairs:stair_inner_stone", param2 = 0, prob = 254}
		local O6 = {name = "stairs:stair_inner_stone", param2 = 1, prob = 254}
		local O7 = {name = "stairs:stair_inner_stone", param2 = 2, prob = 254}
		local O8 = {name = "stairs:stair_inner_stone", param2 = 3, prob = 254}

		local JW = {name = "default:junglewood", param2 = 0, prob = 254}
		local PW = {name = "default:pine_wood", param2 = 0, prob = 254}
		

		local DD = {name = "default:dirt", param2 = 0, prob = 254}
		local DG = {name = "default:dirt_with_grass", param2 = 0, prob = 254}
		local GR = {name = "default:dirt_with_grass", param2 = 0, prob = 254}
		local G1 = {name = "default:glass", param2 = 0, prob = 254}

		local FF = {name = "farming:soil_wet", param2 = 0, prob = 254}
		local CC = {name = "farming:corn_5", param2 = 0, prob = 254}
		
		
		local F0 = {name = "furnace:furnace", param2 = 0, prob = 254}
		local F1 = {name = "furnace:furnace", param2 = 1, prob = 254}
		local F2 = {name = "furnace:furnace", param2 = 2, prob = 254}
		local F3 = {name = "furnace:furnace", param2 = 3, prob = 254}

		local C0 = {name = "default:chest", param2 = 0, prob = 254}
		local C1 = {name = "default:chest", param2 = 1, prob = 254}
		local C2 = {name = "default:chest", param2 = 2, prob = 254}
		local C3 = {name = "default:chest", param2 = 3, prob = 254}

		local L0 = {name = "default:ladder_wood", param2 = 0, prob = 254}
		local L1 = {name = "default:ladder_wood", param2 = 1, prob = 254}
		local L2 = {name = "default:ladder_wood", param2 = 2, prob = 254}
		local L3 = {name = "default:ladder_wood", param2 = 3, prob = 254}
		local L4 = {name = "default:ladder_wood", param2 = 4, prob = 254}
		local L5 = {name = "default:ladder_wood", param2 = 5, prob = 254}

		local DR = {name = "lib_doors:tree_default_wood_door_centered_300_height_150_width_right", param2 = 1, prob = 254}
		local DL = {name = "lib_doors:tree_default_wood_door_centered_300_height_150_width", param2 = 1, prob = 254}
		local D0 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 0, prob = 254}
		local D1 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 1, prob = 254}
		local D2 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 2, prob = 254}
		local D3 = {name = "lib_doors:tree_default_wood_door_centered_with_window", param2 = 3, prob = 254}
		local D5 = {name = "doors:trapdoor", param2 = 0, prob = 254}
		local D6 = {name = "doors:trapdoor", param2 = 1, prob = 254}
		local D7 = {name = "doors:trapdoor", param2 = 2, prob = 254}
		local D8 = {name = "doors:trapdoor", param2 = 3, prob = 254}

		local TC = {name = "default:torch_ceiling", param2 = 0, prob = 254}
		local TT = {name = "default:torch", param2 = 1, prob = 254}
		local T1 = {name = "default:torch_wall", param2 = 1, prob = 254}
		local T2 = {name = "default:torch_wall", param2 = 2, prob = 254}
		local T3 = {name = "default:torch_wall", param2 = 3, prob = 254}
		local T4 = {name = "default:torch_wall", param2 = 4, prob = 254}
		local T5 = {name = "default:torch_wall", param2 = 5, prob = 254}
		local T6 = {name = "decoblocks:lantern_wall", param2 = 2, prob = 254}
		local T7 = {name = "decoblocks:lantern_wall", param2 = 3, prob = 254}
		local T8 = {name = "decoblocks:lantern_wall", param2 = 4, prob = 254}
		local T9 = {name = "decoblocks:lantern_wall", param2 = 5, prob = 254}
		local T0 = {name = "decoblocks:lantern_ceiling", param2 = 0, prob = 254}

		local A0 = {name = "lib_tools:anvil", param2 = 0, prob = 254}
		local A1 = {name = "lib_tools:anvil", param2 = 1, prob = 254}
		local A2 = {name = "lib_tools:anvil", param2 = 2, prob = 254}
		local A3 = {name = "lib_tools:anvil", param2 = 3, prob = 254}
		local AA = {name = "decoblocks:altar", param2 = 2, prob = 254}

		local B0 = {name = "beds:bed_bottom", param2 = 0, prob = 254}
		local B1 = {name = "beds:bed_bottom", param2 = 1, prob = 254}
		local B2 = {name = "beds:bed_bottom", param2 = 2, prob = 254}
		local B3 = {name = "beds:bed_bottom", param2 = 3, prob = 254}
		local B5 = {name = "beds:bed_top", param2 = 0, prob = 254}
		local B6 = {name = "beds:bed_top", param2 = 1, prob = 254}
		local B7 = {name = "beds:bed_top", param2 = 2, prob = 254}
		local B8 = {name = "beds:bed_top", param2 = 3, prob = 254}
		local BN = {name = "default:bookshelf", param2 = 0, prob = 254}
		local BE = {name = "default:bookshelf", param2 = 1, prob = 254}
		local BS = {name = "default:bookshelf", param2 = 2, prob = 254}
		local BW = {name = "default:bookshelf", param2 = 3, prob = 254}

		local RB = {name = "lib_tools:ropebox", param2 = 3, prob = 254}
		local RP = {name = "lib_tools:box_rope", param2 = 0, prob = 254}

		local R1 = {name = "cottages:roof_wood", param2 = 1, prob = 254}
		local R3 = {name = "cottages:roof_wood", param2 = 3, prob = 254}
		local R5 = {name = "cottages:roof_connector_wood", param2 = 1, prob = 254}
		local R7 = {name = "cottages:roof_connector_wood", param2 = 3, prob = 254}

		local X0 = {name = "xpanes:bar_flat", param2 = 0, prob = 254}
		local X1 = {name = "xpanes:bar_flat", param2 = 1, prob = 254}
		local X2 = {name = "xpanes:bar_flat", param2 = 2, prob = 254}
		local X3 = {name = "xpanes:bar_flat", param2 = 3, prob = 254}
		local X5 = {name = "xpanes:framed_pane_flat", param2 = 0, prob = 254}
		local X6 = {name = "xpanes:framed_pane_flat", param2 = 1, prob = 254}
		local X7 = {name = "xpanes:framed_pane_flat", param2 = 2, prob = 254}
		local X8 = {name = "xpanes:framed_pane_flat", param2 = 3, prob = 254}

		local Z1 = {name = "lib_tools:cauldron_empty", param2 = 0, prob = 254}
		local Z2 = {name = "lib_furniture:tree_default_table_basic_01", param2 = 0, prob = 254}
		local Z3 = {name = "default:steelblock", param2 = 0, prob = 254}
		local Z4 = {name = "xpanes:bar_flat", param2 = 1, prob = 254}
		local Z5 = {name = "mg_villages:mob_workplace_marker", param2 = 0, prob = 254}
		local Z6 = {name = "cottages:shelf", param2 = 1, prob = 254}
		local Z7 = {name = "cottages:shelf", param2 = 3, prob = 254}
		local Z8 = {name = "cottages:table", param2 = 2, prob = 254}

		local I0 = {name = "xdecor:workbench",param2 = 0,prob = 254}
		local I1 = {name = "xdecor:workbench",param2 = 1,prob = 254}
		local I2 = {name = "xdecor:workbench",param2 = 2,prob = 254}
		local I3 = {name = "xdecor:workbench",param2 = 3,prob = 254}
		local I4 = {name = "",param2 = 0,prob = 254}
		local I5 = {name = "lib_tools:draft_table",param2 = 0,prob = 254}
		local I6 = {name = "decoblocks:vase",param2 = 0,prob = 254}
		local I7 = {name = "lib_relic:baked_clay_red_vase_large_01",param2 = 0,prob = 254}
		local I8 = {name = "",param2 = 0,prob = 254}
		local I9 = {name = "",param2 = 0,prob = 254}

		local II = {name = "default:fence_wood",param2 = 0,prob = 254}

		Q0 = {name = "stairs:slab_stonebrick", param2 = 8, prob = 254}
		
		towns_imperial.schem_bldg_church_stone_x11_y16_z20_r000 = {
			size = {x = 11,y = 16,z = 20},
			data = {
				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, S0, __, M6, __, S0, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, T8, __, T8, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, S1, M2, M2, M2, M2, M2, S3, __, __,
				__, __, __, M2, M1, D2, M1, M2, __, __, __,
				__, __, __, M2, M1, __, M1, M2, __, __, __,
				__, __, __, M2, M1, M1, M1, M2, __, __, __,
				__, __, __, M2, M2, M2, M2, M2, __, __, __,
				__, __, __, M2, M1, M1, M1, M2, __, __, __,
				__, __, __, M2, M1, X5, M1, M2, __, __, __,
				__, __, __, M2, M1, X5, M1, M2, __, __, __,
				__, __, __, M2, M2, M2, M2, M2, __, __, __,
				__, __, __, M2, M1, M1, M1, M2, __, __, __,
				__, __, __, M2, M1, __, M1, M2, __, __, __,
				__, __, __, M2, M1, __, M1, M2, __, __, __,
				__, __, __, M2, M2, M2, M2, M2, __, __, __,
				__, __, __, M2, M1, M1, M1, M2, __, __, __,
				__, __, __, M2, S3, __, S1, M2, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, M2, PW, PW, PW, M2, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M2, PW, PW, PW, M2, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M2, PW, PW, PW, M2, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M2, PW, PW, PW, M2, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, S2, __, __, __, S2, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, M2, PW, PW, PW, M2, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M1, __, T0, __, M1, __, __, __,
				__, __, __, M2, PW, PW, PW, M2, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, M1, __, T0, __, M1, __, __, __,
				__, __, __, M2, PW, PW, PW, M2, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, T0, __, __, __, __, __,
				__, __, __, M2, PW, PW, PW, M2, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, S0, __, M2, PW, PW, PW, M2, __, S0, __,
				__, __, __, M1, __, __, L2, M1, __, __, __,
				__, __, __, M1, __, __, L2, M1, __, __, __,
				S1, __, __, M1, __, __, L2, M1, __, __, S3,
				__, S1, __, M2, PW, PW, L2, M2, __, S3, __,
				__, __, S1, M1, __, __, L2, M1, S3, __, __,
				__, __, __, M1, __, __, L2, M1, __, __, __,
				__, __, __, M1, __, __, L2, M1, __, __, __,
				__, __, __, M2, PW, PW, L2, M2, __, __, __,
				__, __, __, M1, __, __, L2, M1, __, __, __,
				__, __, __, M1, __, __, L2, M1, __, __, __,
				__, __, __, M1, __, __, L2, M1, __, __, __,
				__, __, __, M2, PW, PW, L2, M2, __, __, __,
				__, __, __, M1, __, __, __, M1, __, __, __,
				__, __, __, S0, __, __, __, S0, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				S1, M2, M2, M2, PW, PW, PW, M2, M2, M2, S3,
				__, M2, M1, M2, __, __, __, M2, M1, M2, __,
				__, M2, M1, M2, __, __, __, M2, M1, M2, __,
				S1, M2, M1, M2, __, __, __, M2, M1, M2, S3,
				__, S1, M1, M2, M2, M2, M2, M2, M1, S3, __,
				__, __, S1, M2, M1, M1, M1, M2, S3, __, __,
				__, __, __, M2, M1, M1, M1, M2, __, __, __,
				__, __, __, M2, M1, M1, M1, M2, __, __, __,
				__, __, __, M2, M2, M2, M2, M2, __, __, __,
				__, __, __, M2, M1, M1, M1, M2, __, __, __,
				__, __, __, M2, M1, __, M1, M2, __, __, __,
				__, __, __, M2, M1, __, M1, M2, __, __, __,
				__, __, __, M2, M2, M2, M2, M2, __, __, __,
				__, __, __, M2, M1, M1, M1, M2, __, __, __,
				__, __, __, M2, S3, __, S1, M2, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, M2, PW, PW, PW, PW, PW, PW, PW, M2, __,
				__, M1, __, __, __, __, __, __, __, M1, __,
				__, M1, __, T9, __, __, __, T9, __, M1, __,
				S1, M1, __, __, __, __, __, __, __, M1, S3,
				__, S1, __, __, __, __, __, __, __, S3, __,
				__, __, S1, __, __, __, __, __, S3, __, __,
				__, __, __, S1, __, __, __, S3, __, __, __,
				__, __, __, __, S1, __, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, M2, PW, PW, PW, PW, PW, PW, PW, M2, __,
				__, M1, __, __, __, __, __, __, __, M1, __,
				__, X8, __, __, __, __, __, __, __, X8, __,
				S1, M1, __, __, __, __, __, __, __, M1, S3,
				__, S1, __, __, __, __, __, __, __, S3, __,
				__, __, S1, __, __, __, __, __, S3, __, __,
				__, __, __, S1, __, __, __, S3, __, __, __,
				__, __, __, __, S1, __, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, M2, PW, PW, PW, PW, PW, PW, PW, M2, __,
				__, M1, S2, S2, __, __, __, S2, S2, M1, __,
				__, M1, __, __, __, __, __, __, __, M1, __,
				S1, M1, __, __, __, __, __, __, __, M1, S3,
				__, S1, __, __, __, __, __, __, __, S3, __,
				__, __, S1, __, __, __, __, __, S3, __, __,
				__, __, __, S1, __, __, __, S3, __, __, __,
				__, __, __, __, S1, __, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				S1, M2, PW, PW, PW, PW, PW, PW, PW, M2, S3,
				__, M2, __, __, __, __, __, __, __, M2, __,
				__, M2, T7, __, __, __, __, __, T6, M2, __,
				S1, M2, __, __, __, __, __, __, __, M2, S3,
				__, S1, M2, __, __, __, __, __, M2, S3, __,
				__, __, S1, M2, __, __, __, M2, S3, __, __,
				__, __, __, S1, M2, __, M2, S3, __, __, __,
				__, __, __, __, S1, M2, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, M2, PW, PW, PW, PW, PW, PW, PW, M2, __,
				__, M1, S2, S2, __, __, __, S2, S2, M1, __,
				__, M1, __, __, __, __, __, __, __, M1, __,
				S1, M1, __, __, __, __, __, __, __, M1, S3,
				__, S1, __, __, __, __, __, __, __, S3, __,
				__, __, S1, __, __, __, __, __, S3, __, __,
				__, __, __, S1, __, __, __, S3, __, __, __,
				__, __, __, __, S1, __, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, M2, PW, PW, PW, PW, PW, PW, PW, M2, __,
				__, M1, __, __, __, __, __, __, __, M1, __,
				__, X8, __, __, __, __, __, __, __, X8, __,
				S1, M1, __, __, __, __, __, __, __, M1, S3,
				__, S1, __, __, __, __, __, __, __, S3, __,
				__, __, S1, __, __, __, __, __, S3, __, __,
				__, __, __, S1, __, __, __, S3, __, __, __,
				__, __, __, __, S1, __, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, M2, PW, PW, PW, PW, PW, PW, PW, M2, __,
				__, M1, S2, S2, __, __, __, S2, S2, M1, __,
				__, M1, __, __, __, __, __, __, __, M1, __,
				S1, M1, __, __, __, __, __, __, __, M1, S3,
				__, S1, __, __, __, __, __, __, __, S3, __,
				__, __, S1, __, __, __, __, __, S3, __, __,
				__, __, __, S1, __, __, __, S3, __, __, __,
				__, __, __, __, S1, __, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				S1, M2, PW, PW, PW, PW, PW, PW, PW, M2, S3,
				__, M2, __, __, __, __, __, __, __, M2, __,
				__, M2, T7, __, __, __, __, __, T6, M2, __,
				S1, M2, __, __, __, __, __, __, __, M2, S3,
				__, S1, M2, __, __, __, __, __, M2, S3, __,
				__, __, S1, M2, __, __, __, M2, S3, __, __,
				__, __, __, S1, M2, __, M2, S3, __, __, __,
				__, __, __, __, S1, M2, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, M2, PW, PW, PW, PW, PW, PW, PW, M2, __,
				__, M1, __, __, Q0, Q0, Q0, __, __, M1, __,
				__, M1, __, __, __, __, __, __, __, M1, __,
				S1, M1, __, __, __, __, __, __, __, M1, S3,
				__, S1, __, __, __, __, __, __, __, S3, __,
				__, __, S1, __, __, __, __, __, S3, __, __,
				__, __, __, S1, __, __, __, S3, __, __, __,
				__, __, __, __, S1, __, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, M2, PW, PW, PW, PW, PW, PW, PW, M2, __,
				__, M1, __, S1, M2, M2, M2, S3, __, M1, __,
				__, X8, __, __, __, AA, __, __, __, X8, __,
				S1, M1, __, __, __, __, __, __, __, M1, S3,
				__, S1, __, __, __, __, __, __, __, S3, __,
				__, __, S1, __, __, __, __, __, S3, __, __,
				__, __, __, S1, __, __, __, S3, __, __, __,
				__, __, __, __, S1, __, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, M2, PW, PW, PW, PW, PW, PW, PW, M2, __,
				__, M1, __, S1, M2, M2, M2, S3, __, M1, __,
				__, M1, __, __, __, __, __, __, __, M1, __,
				S1, M1, __, __, __, __, __, __, __, M1, S3,
				__, S1, __, __, __, __, __, __, __, S3, __,
				__, __, S1, __, __, __, __, __, S3, __, __,
				__, __, __, S1, __, __, __, S3, __, __, __,
				__, __, __, __, S1, __, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				S1, M2, M2, M2, M2, M2, M2, M2, M2, M2, S3,
				__, M2, M1, M1, M1, M1, M1, M1, M1, M2, __,
				__, M2, M1, M1, X5, X5, X5, M1, M1, M2, __,
				S1, M2, M1, M1, X5, X5, X5, M1, M1, M2, S3,
				__, S1, M2, M1, X5, X5, X5, M1, M2, S3, __,
				__, __, S1, M2, M1, X5, M1, M2, S3, __, __,
				__, __, __, S1, M2, M1, M2, S3, __, __, __,
				__, __, __, __, S1, M2, S3, __, __, __, __,
				__, __, __, __, __, M7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, S2, __, __, __, __, __, __, __, S2, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				S1, __, __, __, __, __, __, __, __, __, S3,
				__, S1, __, __, __, __, __, __, __, S3, __,
				__, __, S1, __, __, __, __, __, S3, __, __,
				__, __, __, S1, __, __, __, S3, __, __, __,
				__, __, __, __, S1, S7, S3, __, __, __, __,
				__, __, __, __, __, S0, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, S7, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254},
				{ypos = 5,prob = 254},
				{ypos = 6,prob = 254},
				{ypos = 7,prob = 254},
				{ypos = 8,prob = 254},
				{ypos = 9,prob = 254},
				{ypos = 10,prob = 254},
				{ypos = 11,prob = 254},
				{ypos = 12,prob = 254},
				{ypos = 13,prob = 254},
				{ypos = 14,prob = 254},
				{ypos = 15,prob = 254}
			}
		}


		towns_imperial.schem_bldg_village_farm_01_x9_y3_z13_r000 = {
			size = {x = 9,y = 3,z = 13},
			data = {
				DD, DD, DD, DD, DD, DD, DD, DD, DD, 
				NY, II, II, II, II, II, II, II, NY, 
				NY, __, __, __, __, __, __, __, NY, 

				DD, FF, FF, FF, wt, FF, FF, FF, DD, 
				II, CC, CC, CC, __, CC, CC, CC, II, 
				__, __, __, __, __, __, __, __, __, 

				DD, FF, FF, FF, wt, FF, FF, FF, DD, 
				II, CC, CC, CC, __, CC, CC, CC, II, 
				__, __, __, __, __, __, __, __, __, 

				DD, FF, FF, FF, wt, FF, FF, FF, DD, 
				II, CC, CC, CC, __, CC, CC, CC, II, 
				__, __, __, __, __, __, __, __, __, 

				DD, FF, FF, FF, wt, FF, FF, FF, DD, 
				II, CC, CC, CC, __, CC, CC, CC, II, 
				__, __, __, __, __, __, __, __, __, 

				DD, FF, FF, FF, wt, FF, FF, FF, DD, 
				II, CC, CC, CC, __, CC, CC, CC, II, 
				__, __, __, __, __, __, __, __, __, 

				M1, FF, FF, FF, wt, FF, FF, FF, N3, 
				{param2 = 1,name = "doors:gate_wood_closed",prob = 254}, CC, CC, CC, __, CC, CC, CC, {param2 = 3,name = "doors:gate_wood_closed",prob = 254}, 
				__, __, __, __, __, __, __, __, __, 

				DD, FF, FF, FF, wt, FF, FF, FF, DD, 
				II, CC, CC, CC, __, CC, CC, CC, II, 
				__, __, __, __, __, __, __, __, __, 

				DD, FF, FF, FF, wt, FF, FF, FF, DD, 
				II, CC, CC, CC, __, CC, CC, CC, II, 
				__, __, __, __, __, __, __, __, __, 

				DD, FF, FF, FF, wt, FF, FF, FF, DD, 
				II, CC, CC, CC, __, CC, CC, CC, II, 
				__, __, __, __, __, __, __, __, __, 

				DD, FF, FF, FF, wt, FF, FF, FF, DD, 
				II, CC, CC, CC, __, CC, CC, CC, II, 
				__, __, __, __, __, __, __, __, __, 

				DD, FF, FF, FF, wt, FF, FF, FF, DD, 
				II, CC, CC, CC, __, CC, CC, CC, II, 
				__, __, __, __, __, __, __, __, __, 

				DD, DD, DD, DD, DD, DD, DD, DD, DD, 
				NY, II, II, II, II, II, II, II, NY, 
				NY, __, __, __, __, __, __, __, NY
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254}
			}
		}

		Q3 = {name = "stairs:slab_cobble", param2 = 0, prob = 254}
		Q4 = {name = "stairs:slab_cobble", param2 = 20, prob = 254}

		towns_imperial.schem_bldg_village_03_x13_y8_z7_r000 = {
			size = {x = 13,y = 8,z = 7},
			data = {
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, M6, Q3, Q3, __,
				{param2 = 0,name = "stairs:stair_mossycobble",prob = 254}, __, __, __,
				{param2 = 0,name = "stairs:stair_mossycobble",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M6, M6,
				{param2 = 0,name = "stairs:stair_mossycobble",prob = 254},
				{param2 = 0,name = "stairs:stair_mossycobble",prob = 254},
				{param2 = 0,name = "stairs:stair_mossycobble",prob = 254}, M6,
				{param2 = 0,name = "stairs:stair_mossycobble",prob = 254}, M6, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, DD, DD, DD, DD, __, __, __,
				{param2 = 1,name = "stairs:stair_cobble",prob = 254}, M1, M1, N3, N3, N3, M1, N3, M1, M1,
				{param2 = 3,name = "stairs:stair_cobble",prob = 254}, __, __, __, N3, M2, M2, N4, M1, M2, M2, N4, N3, __, __, __, __, __, M2, __, N4, N3, N4, __, M2, M1, __, __, __, __, __, Q3, N4, M2, N3, N4, M2, N4, M1,
				{param2 = 22,name = "stairs:stair_mossycobble",prob = 254}, __, __, __, __, __, __, S0, S0, S0, S0, S0, S0, M6, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, DD, DD, DD, DD, __, __, __, Q3, M1, N5, N7, N5, N7, N6, N5, N6, M1, __, __, __, __, N4,
				{param2 = 0,name = "mapgen:moss",prob = 254}, Q3, __,
				{param2 = 0,name = "mapgen:moss",prob = 254},
				{param2 = 0,name = "mapgen:moss",prob = 254}, __, C2, M2, __, __, __, __, __, __, __, __, __, __, __, __, N4, __, __, __, __, __, __, __, __, __, __, __, __, N4, __, __, __, __, __, __, __, __, __, __, __, __, M2,
				{param2 = 22,name = "stairs:stair_cobble",prob = 254}, __, __, __, __, __, __, __, S0, S0, S0, S0, S0, M6, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, DD, DD, DD, DD, __, __, __, __, N3, N6, N6, N5, N6, N6, N7, N5, N3, __,
				{param2 = 1,name = "stairs:stair_cobble",prob = 254},
				{param2 = 21,name = "stairs:stair_cobble",prob = 254}, __, __, __, __, M2, __,
				{param2 = 0,name = "mapgen:moss",prob = 254},
				{param2 = 0,name = "mapgen:moss",prob = 254},
				{param2 = 0,name = "mapgen:moss",prob = 254}, N4, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, M2, __, __, __, __, __, __, __, __, __, __, __, __, M2, __, __, __, __, __, __, __, __, __, Q4, Q4, Q4, N4, Q4, __, __, __, __, __, __, __, __,
				{param2 = 3,name = "stairs:slab_mossycobble",prob = 254}, Q3,
				{param2 = 3,name = "stairs:slab_mossycobble",prob = 254}, Q3, Q3, __, __, __, DD, DD, DD, DD, DD, DD, DD, DD, DD, __, __, __, __, N3, N7, N5, N6, N7, N7, N5, N6, N3, __, __, __, __, Q3, __,
				{param2 = 0,name = "mapgen:moss",prob = 254}, __, M1, M2, __, __, M2, __, __, __, __, __, __, __, __, M2, __, __, __, N4, __, __, __, __, __, __, __, __, __, __, __, __, N4, __, __, __, __, __, __, __, __, __, __, __, __, N4,
				{param2 = 20,name = "stairs:stair_mossycobble",prob = 254}, __, __, __, __, __, __, __, __, __, __, S2, S2,
				{param2 = 2,name = "stairs:stair_cobble",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, DD, DD, DD, DD, DD, DD, DD, DD, DD, __, __, __,
				{param2 = 1,name = "stairs:stair_cobble",prob = 254}, N3, N3, M1, M1, N3, M1, M1, N3, M1,
				{param2 = 3,name = "stairs:stair_mossycobble",prob = 254}, __, __, __, __,
				{param2 = 0,name = "mapgen:moss",prob = 254}, N4, N4, N3, M2, N4, M2, M1, __, __, __, __, __, __, __, __, M1, N4, __, M2, N3, __, __, __, __, __, __, __, __, __, N4, N4, M2, M1,
				{param2 = 20,name = "stairs:stair_cobble",prob = 254}, __, __, __, __, __, __, __, __, S2, S2, S2, S2,
				{param2 = 2,name = "stairs:stair_mossycobble",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				{param2 = 2,name = "stairs:stair_cobble",prob = 254}, __, __, __,
				{param2 = 2,name = "stairs:stair_mossycobble",prob = 254}, __, __, __,
				{param2 = 2,name = "stairs:stair_cobble",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				{param2 = 2,name = "stairs:stair_cobble",prob = 254},
				{param2 = 2,name = "stairs:stair_cobble",prob = 254},
				{param2 = 2,name = "stairs:stair_mossycobble",prob = 254},
				{param2 = 2,name = "stairs:stair_cobble",prob = 254},
				{param2 = 2,name = "stairs:stair_mossycobble",prob = 254}, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254},
				{ypos = 5,prob = 254},
				{ypos = 6,prob = 254},
				{ypos = 7,prob = 254}
			}
		}



		O0 = {name = "stairs:stair_outer_stone", param2 = 0, prob = 254}
		O1 = {name = "stairs:stair_outer_stone", param2 = 1, prob = 254}
		O5 = {name = "stairs:stair_inner_stone", param2 = 0, prob = 254}
		O6 = {name = "stairs:stair_inner_stone", param2 = 1, prob = 254}


		towns_imperial.schem_bldg_village_04_x19_y13_z14_r000 = {
			size = {x = 19,y = 13,z = 14},
			data = {
				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, Q2, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, S1, S6, __, __, __, __, __, S8, S3, __, __, __, __, __,
				__, __, __, __, __, __, S1, S6, __, __, __, S8, S3, __, __, __, __, __, __,
				__, __, __, __, __, __, __, S1, S6, __, S8, S3, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, S1, Q2, S3, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, S2, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, S0, __, M6, __, S0, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, T8, __, T8, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, NX, NX, NX, NX, NX, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, NY, M4, M4, M4, NY, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, NY, M4, X5, M4, NY, __, __, __, __, __, __, __,
				__, __, __, __, __, S1, S6, NY, NX, NX, NX, NY, S8, S3, __, __, __, __, __,
				__, __, __, __, __, __, S1, NY, M4, M4, M4, NY, S3, __, __, __, __, __, __,
				__, __, __, __, __, __, __, S1, NY, M4, NY, S3, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, S1, NY, S3, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, M5, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, S1, NY, N3, M1, M1, NY, S3, __, __, __, __, __, __,
				__, __, __, __, __, __, __, NY, M2, D2, M2, NY, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, NY, M2, __, M2, NY, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, NY, M2, M2, M2, NY, __, __, __, __, __, __, __,
				__, __, __, __, __, __, NZ, NY, PW, PW, PW, NY, NX, __, __, __, __, __, __,
				__, __, __, __, __, __, NY, NY, N9, I2, N9, NY, NY, __, __, __, __, __, __,
				__, __, __, __, __, __, NY, NY, __, __, I6, NY, NY, __, __, __, __, __, __,
				__, __, __, __, __, S1, NY, NY, __, T9, __, NY, NY, S3, __, __, __, __, __,
				__, __, __, __, __, __, S1, NY, __, __, __, NY, S3, __, __, __, __, __, __,
				__, __, __, __, __, __, __, S1, N9, __, N9, S3, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, S1, N9, S3, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, M5, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, N3, PW, PW, PW, M1, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, M2, __, __, __, M2, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, M2, __, __, __, M2, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, M2, __, __, __, M2, __, __, __, __, __, __, __,
				__, __, __, __, __, __, NZ, PW, PW, PW, PW, PW, NZ, __, __, __, __, __, __,
				__, __, __, __, __, __, M4, BW, __, __, __, N9, M4, __, __, __, __, __, __,
				__, __, __, __, __, __, M4, __, __, __, __, __, M4, __, __, __, __, __, __,
				__, __, __, __, __, S1, NZ, __, __, __, __, __, NZ, S3, __, __, __, __, __,
				__, __, __, __, __, __, S1, N9, __, __, __, N9, S3, __, __, __, __, __, __,
				__, __, __, __, __, __, __, S1, N9, __, N9, S3, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, S1, N9, S3, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, M5, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, M1, PW, PW, PW, N3, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, M2, __, __, __, M2, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, X8, __, __, __, X8, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, M2, __, __, __, M2, __, __, __, __, __, __, __,
				__, __, __, __, __, __, NZ, PW, PW, PW, PW, PW, NZ, __, __, __, __, __, __,
				__, __, __, __, __, __, M4, BW, __, __, __, N9, M4, __, __, __, __, __, __,
				__, __, __, __, __, __, M4, __, __, __, __, __, M4, __, __, __, __, __, __,
				__, S0, S0, S0, S0, O6, NZ, __, __, __, __, __, NZ, O5, S0, S0, S0, S0, __,
				__, __, __, __, __, __, S1, N9, __, __, __, N9, S3, __, __, __, __, __, __,
				__, __, __, __, __, __, __, S1, N9, __, N9, S3, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, S1, N9, S3, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, M5, __, __, __, __, __, __, __, __, __,
				
				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, S0, __, __, O1, M1, PW, PW, PW, M1, O0, __, __, S0, __, __, __,
				__, __, __, __, __, __, __, M2, __, __, __, M2, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, M2, __, __, __, M2, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, M2, __, __, __, M2, __, __, __, __, __, __, __,
				__, __, __, NX, NX, NX, NY, PW, PW, PW, PW, PW, NY, NZ, NZ, NX, __, __, __,
				__, __, __, NY, M4, M4, M4, N9, __, __, __, C1, M4, M4, M4, NY, __, __, __,
				__, __, __, NY, M4, M4, M4, I7, __, __, __, __, M4, M4, M4, NY, __, __, __,
				__, S7, S7, NY, NX, NX, NY, __, __, __, __, __, NY, NZ, NZ, NY, S7, S7, __,
				__, S0, S0, S0, S0, S0, {param2 = 1,name = "default:wood_innerstair",prob = 254}, N9, __, __, __, N9, {param2 = 0,name = "default:wood_innerstair",prob = 254}, S0, S0, S0, S0, S0, __,
				__, __, __, __, __, __, __, S1, N9, __, N9, S3, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, S1, N9, S3, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, M5, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, S1, NY, M1, N3, N3, NY, PW, PW, PW, NY, M1, N3, M1, NY, S3, __, __,
				__, __, __, NY, M2, M2, M2, NY, __, __, __, NY, M2, M2, M2, NY, __, __, __,
				__, __, __, NY, M2, X5, M2, NY, __, __, __, NY, M2, X5, M2, NY, __, __, __,
				__, __, __, NY, M2, M2, M2, NY, __, __, __, NY, M2, M2, M2, NY, __, __, __,
				__, __, NZ, NY, PW, PW, PW, NY, PW, PW, PW, NY, PW, PW, PW, NY, NX, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, B8, B3, __, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, __, __, __, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, __, __, __, NY, NY, __, __,
				__, S7, NY, NY, N9, N9, N9, NY, __, __, __, NY, N9, N9, N9, NY, NY, S7, __,
				__, S0, S0, S0, S0, S0, S0, {param2 = 1,name = "default:wood_innerstair",prob = 254}, NY, __, NY, {param2 = 0,name = "default:wood_innerstair",prob = 254}, S0, S0, S0, S0, S0, S0, __,
				__, __, __, __, __, __, __, __, S1, NY, S3, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, M5, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, M1, PW, PW, PW, PW, PW, PW, PW, PW, PW, PW, PW, M1, __, __, __,
				__, __, __, M2, N9, BW, __, __, __, __, __, __, __, __, M2, M2, __, __, __,
				__, __, __, M2, PW, I7, __, __, __, __, __, T9, __, __, __, M2, __, __, __,
				__, __, __, M2, __, {param2 = 1,name = "stairs:slab_pine_wood",prob = 254}, {param2 = 22,name = "stairs:slab_pine_wood",prob = 254}, __, __, __, __, __, __, __, __, M2, __, __, __,
				__, __, NZ, PW, __, __, __, PW, PW, PW, PW, PW, PW, PW, PW, PW, NZ, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, __, __, __, C1, M4, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, __, NZ, __, __, __, __, __, __, __, __, __, __, __, __, __, NZ, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, S7, NY, N9, N9, N9, N9, NY, N9, __, N9, NY, N9, N9, N9, N9, NY, S7, __,
				__, S0, S0, S0, S0, S0, S0, S0, {param2 = 1,name = "default:wood_innerstair",prob = 254}, N9, {param2 = 0,name = "default:wood_innerstair",prob = 254}, S0, S0, S0, S0, S0, S0, S0, __,
				__, __, __, __, __, __, __, __, __, M5, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, N3, PW, PW, PW, PW, PW, PW, PW, PW, PW, PW, PW, N3, __, __, __,
				__, __, __, M2, N9, NY, __, __, __, __, __, __, __, __, F1, M2, __, __, __,
				__, __, __, X8, {param2 = 2,name = "stairs:slab_pine_wood",prob = 254}, NY, T7, __, __, __, __, __, __, __, __, X8, __, __, __,
				__, __, __, M2, __, NY, __, __, __, __, __, __, __, __, __, M2, __, __, __,
				__, __, NZ, PW, __, NY, {param2 = 0,name = "stairs:slab_pine_wood",prob = 254}, PW, PW, PW, PW, PW, PW, PW, PW, PW, NZ, __, __,
				__, __, M4, __, __, NY, __, __, __, __, __, __, __, __, __, C1, M4, __, __,
				__, __, X8, __, __, __, __, __, __, __, __, __, __, __, __, __, X8, __, __,
				__, __, NZ, T7, __, __, __, __, __, __, __, __, __, __, __, T6, NZ, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, S8, NY, N9, N9, N9, N9, NY, N9, N9, N9, NY, N9, N9, N9, N9, NY, S6, __,
				S8, S3, M5, M5, M5, M5, M5, M5, M5, M5, M5, M5, M5, M5, M5, M5, M5, S1, S6,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, M1, PW, PW, PW, PW, PW, PW, PW, PW, PW, PW, PW, N3, __, __, __,
				__, __, __, M2, PW, {param2 = 1,name = "stairs:slab_pine_wood",prob = 254}, __, __, __, __, __, __, __, __, M2, M2, __, __, __,
				__, __, __, M2, __, __, __, __, __, __, __, __, __, __, I7, M2, __, __, __,
				__, __, __, M2, __, __, __, __, __, __, __, __, __, __, __, M2, __, __, __,
				__, __, NZ, PW, __, {param2 = 23,name = "stairs:stair_pine_wood",prob = 254}, PW, PW, PW, PW, PW, PW, PW, PW, PW, PW, NZ, __, __,
				__, __, M4, I6, __, II, __, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, __, NZ, __, __, __, __, __, __, __, __, __, __, __, __, __, NZ, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, Q2, NY, N9, N9, N9, N9, NY, N9, N9, N9, NY, N9, N9, N9, N9, NY, Q2, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, S1, NY, N3, N3, M1, NY, M1, M1, N3, NY, N3, M1, M1, NY, S3, __, __,
				__, __, __, NY, M2, M2, M2, NY, M2, M2, M2, NY, M2, M2, M2, NY, __, __, __,
				__, __, __, NY, M2, X5, M2, NY, M2, X5, M2, NY, M2, X5, M2, NY, __, __, __,
				__, __, __, NY, M2, M2, M2, NY, M2, M2, M2, NY, M2, M2, M2, NY, __, __, __,
				__, __, NZ, NY, PW, PW, PW, NY, PW, PW, PW, NY, PW, PW, PW, NY, NX, __, __,
				__, __, NY, NY, __, II, __, NY, __, __, __, NY, BN, BN, BN, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, __, __, __, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, __, __, __, NY, NY, __, __,
				__, Q2, NY, NY, N9, N9, N9, NY, N9, N9, N9, NY, N9, N9, N9, NY, NY, Q2, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, S2, __, __, __, S2, __, __, __, S2, __, __, __, S2, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, NZ, NZ, NZ, NZ, NZ, NZ, NZ, NZ, NZ, NZ, NZ, NZ, NZ, __, __, __,
				__, __, __, NY, M4, M4, M4, NY, M4, M4, M4, NY, M4, M4, M4, NY, __, __, __,
				__, __, __, NY, M4, X5, M4, NY, M4, X5, M4, NY, M4, X5, M4, NY, __, __, __,
				__, Q2, Q2, NY, NZ, NZ, NZ, NY, NZ, NZ, NZ, NY, NZ, NZ, NZ, NY, Q2, Q2, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __, __
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254},
				{ypos = 5,prob = 254},
				{ypos = 6,prob = 254},
				{ypos = 7,prob = 254},
				{ypos = 8,prob = 254},
				{ypos = 9,prob = 254},
				{ypos = 10,prob = 254},
				{ypos = 11,prob = 254},
				{ypos = 12,prob = 254}
			}
		}

		QN = {name = "stairs:stair_wood", param2 = 20, prob = 254}
		QE = {name = "stairs:stair_wood", param2 = 21, prob = 254}
		Q5 = {name = "stairs:stair_wood", param2 = 22, prob = 254}
		QW = {name = "stairs:stair_wood", param2 = 23, prob = 254}


		towns_imperial.schem_bldg_village_05_x15_y13_z9_r000 = {
			size = {x = 15,y = 13,z = 9},
			data = {
				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, S0, __, __, __, S0, __, M6, __, S0, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, T8, __, T8, __, __, __, __,
				__, __, __, QN, __, __, __, QN, __, __, __, QN, __, __, __,
				__, __, __, NX, NZ, NZ, NZ, NX, NZ, NZ, NZ, NX, __, __, __,
				__, __, __, NY, M4, M4, M4, NY, M4, M4, M4, NY, __, __, __,
				__, __, __, NY, M4, X5, M4, NY, M4, X5, M4, NY, __, __, __,
				__, S7, S7, NY, NX, NX, NX, NY, NX, NX, NX, NY, S7, S7, __,
				__, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, S1, NY, N3, M1, M1, NY, M1, N3, M1, NY, S3, __, __,
				__, __, __, NY, M2, M2, M2, NY, M2, D2, M2, NY, __, __, __,
				__, __, __, NY, M2, X5, M2, NY, M2, __, M2, NY, __, __, __,
				__, __, QW, NY, M2, M2, M2, NY, M2, M2, M2, NY, QE, __, __,
				__, __, NZ, NY, PW, PW, PW, NY, PW, PW, PW, NY, NX, __, __,
				__, __, NY, NY, __, __, __, NY, BS, BS, BS, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, I7, __, __, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, NY, __, __,
				__, S7, NY, NY, N9, N9, N9, NY, N9, N9, N9, NY, NY, S7, __,
				__, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				
				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, N3, PW, PW, PW, PW, PW, PW, PW, N3, __, __, __,
				__, __, __, M2, N9, BW, __, __, __, __, __, M2, __, __, __,
				__, __, __, M2, PW, I7, __, __, __, __, __, M2, __, __, __,
				__, __, __, M2, __, {param2 = 1,name = "stairs:slab_pine_wood",prob = 254}, {param2 = 22,name = "stairs:slab_pine_wood",prob = 254}, __, __, __, __, M2, __, __, __,
				__, __, NZ, PW, __, __, __, PW, PW, PW, PW, PW, NZ, __, __,
				__, __, M4, I6, __, __, __, __, __, __, __, I1, M4, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, __, NZ, __, __, __, __, __, __, __, __, __, NZ, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, S7, NY, NY, N9, N9, N9, NY, N9, N9, N9, NY, NY, S7, __,
				__, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, M1, PW, PW, PW, PW, PW, PW, PW, N3, __, __, __,
				__, __, __, M2, N9, NY, __, __, __, __, __, M2, __, __, __,
				__, __, __, X8, {param2 = 2,name = "stairs:slab_pine_wood",prob = 254}, NY, T7, __, __, __, __, X8, __, __, __,
				__, __, __, M2, __, NY, __, __, __, __, __, M2, __, __, __,
				__, __, NZ, PW, __, NY, {param2 = 3,name = "stairs:slab_pine_wood",prob = 254}, PW, PW, PW, PW, PW, NZ, __, __,
				__, __, M4, __, __, NY, __, __, __, __, __, __, M4, __, __,
				__, __, X8, __, __, __, __, __, __, __, __, __, X8, __, __,
				__, __, NZ, T7, __, __, __, __, __, __, __, T6, NZ, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, S8, NY, NY, N9, N9, N9, NY, N9, N9, N9, NY, NY, S6, __,
				S8, S3, M5, M5, M5, M5, M5, M5, M5, M5, M5, M5, M5, S1, S6,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, N3, PW, PW, PW, PW, PW, PW, PW, M1, __, __, __,
				__, __, __, M2, PW, {param2 = 3,name = "stairs:slab_pine_wood",prob = 254}, __, __, __, F0, F0, M2, __, __, __,
				__, __, __, M2, __, __, __, __, __, __, __, M2, __, __, __,
				__, __, __, M2, __, __, __, __, __, __, __, M2, __, __, __,
				__, __, NZ, PW, __, {param2 = 23,name = "stairs:stair_pine_wood",prob = 254}, PW, PW, PW, PW, PW, PW, NZ, __, __,
				__, __, M4, __, __, II, __, __, __, __, __, __, M4, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, __, NZ, __, __, __, __, __, __, __, __, __, NZ, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, Q2, NY, NY, N9, N9, N9, NY, N9, N9, N9, NY, NY, Q2, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, S1, NY, M1, N3, M1, NY, N3, M1, M1, NY, S3, __, __,
				__, __, __, NY, M2, M2, M2, NY, M2, M2, M2, NY, __, __, __,
				__, __, __, NY, M2, X5, M2, NY, M2, X5, M2, NY, __, __, __,
				__, __, QW, NY, M2, M2, M2, NY, M2, M2, M2, NY, QE, __, __,
				__, __, NZ, NY, PW, PW, PW, NY, PW, PW, PW, NY, NX, __, __,
				__, __, NY, NY, __, II, __, NY, C0, B8, B3, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, NY, __, __,
				__, Q2, NY, NY, N9, N9, N9, NY, N9, N9, N9, NY, NY, Q2, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, S2, __, __, __, S2, __, __, __, S2, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, QS, __, __, __, QS, __, __, __, QS, __, __, __,
				__, __, __, NZ, NX, NX, NX, NZ, NX, NX, NX, NZ, __, __, __,
				__, __, __, NY, M4, M4, M4, NY, M4, M4, M4, NY, __, __, __,
				__, __, __, NY, M4, X5, M4, NY, M4, X5, M4, NY, __, __, __,
				__, Q2, Q2, NY, NX, NX, NX, NY, NX, NX, NX, NY, Q2, Q2, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254},
				{ypos = 5,prob = 254},
				{ypos = 6,prob = 254},
				{ypos = 7,prob = 254},
				{ypos = 8,prob = 254},
				{ypos = 9,prob = 254},
				{ypos = 10,prob = 254},
				{ypos = 11,prob = 254},
				{ypos = 12,prob = 254}
			}
		}


		Q5 = {name = "stairs:slab_wood", param2 = 0, prob = 254}
		Q6 = {name = "stairs:slab_wood", param2 = 20, prob = 254}


		towns_imperial.schem_bldg_village_06_x15_y13_z13_r000 = {
			size = {x = 15,y = 13,z = 13},
			data = {
				DD, DD, M1, N3, N3, N3, N3, M1, M1, M1, M1, M1, N3, N3, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, N3, M1, N3, M1, N3, N3, M1, M1, N3, N3, M1, N3, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, Q6, Q6, Q6, Q6, Q6, Q6, Q6, Q6, Q6, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, N3, N3, M1, M1, M1, N3, M1, N3, M1, N3, N3, M1, DD,
				__, __, __, NY, II, II, II, NY, II, II, II, NY, __, __, __,
				__, __, __, NY, __, __, __, NY, __, __, __, NY, __, __, __,
				__, __, __, NY, __, __, __, NY, __, __, __, NY, __, __, __,
				__, __, __, Q5, Q5, Q5, Q5, Q5, Q5, Q5, Q5, Q5, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, M1, M1, M1, N3, M1, M1, M1, M1, N3, M1, M1, M1, DD,
				__, __, __, II, A0, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, Q5, Q5, Q5, Q5, Q5, Q5, Q5, Q5, Q5, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, M1, N3, M1, M1, M1, M1, M1, N3, M1, M1, M1, M1, DD,
				__, __, __, II, C3, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, Q6, Q6, Q6, Q6, Q6, Q6, Q6, Q6, Q6, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, N3, M1, N3, N3, N3, N3, M1, N3, M1, M1, M1, N3, DD,
				__, __, __, S0, N3, F0, N3, S0, I0, M6, __, S0, __, __, __,
				__, __, __, __, M1, __, N3, __, __, __, __, __, __, __, __,
				__, __, __, __, M1, M1, M1, __, T8, __, T8, __, __, __, __,
				__, __, __, QN, M1, M1, M1, QN, Q6, Q6, Q6, QN, __, __, __,
				__, __, __, NX, NZ, NZ, NZ, NX, NX, NX, NX, NX, __, __, __,
				__, __, __, NY, M4, M4, M4, NY, M4, M4, M4, NY, __, __, __,
				__, __, __, NY, M4, X5, M4, NY, M4, X5, M4, NY, __, __, __,
				__, S7, S7, NY, NX, NX, NX, NY, NX, NX, NX, NY, S7, S7, __,
				__, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, M1, DD, DD, DD, DD, DD, DD, DD, DD, DD, M1, DD, DD,
				__, __, S1, NY, N3, wt, N3, NY, N3, N3, M1, NY, S3, __, __,
				__, __, __, NY, N3, {param2 = 9,name = "stm_nodes:plate",prob = 254}, N3, NY, M2, D2, M2, NY, __, __, __,
				__, __, __, NY, M2, M1, M2, NY, M2, __, M2, NY, __, __, __,
				__, __, QW, NY, M2, M2, M2, NY, M2, M2, M2, NY, QE, __, __,
				__, __, NZ, PW, PW, PW, PW, PW, PW, PW, PW, PW, NX, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, NY, __, __,
				__, S7, NY, NY, N9, N9, N9, NY, N9, N9, N9, NY, NY, S7, __,
				__, S0, S0, M1, M1, S0, S0, S0, S0, S0, S0, S0, S0, S0, __,
				__, __, __, M1, {param2 = 3,name = "stairs:stair_cobble",prob = 254}, __, __, __, __, __, __, __, __, __, __,
				__, __, __, M1, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, M1, PW, N3, PW, PW, PW, PW, PW, M1, __, __, __,
				__, __, __, M2, N3, N3, C3, __, __, __, __, M2, __, __, __,
				__, __, __, M2, PW, M1, I7, __, __, __, __, M2, __, __, __,
				__, __, __, M2, __, {param2 = 3,name = "stairs:slab_pine_wood",prob = 254}, {param2 = 22,name = "stairs:slab_pine_wood",prob = 254}, __, __, __, __, M2, __, __, __,
				__, __, NX, PW, __, __, __, PW, PW, PW, PW, PW, NX, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, B7, M4, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, __, NX, __, __, __, __, __, __, __, __, __, NX, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, S7, NY, NY, N9, N9, N9, NY, N9, N9, N9, NY, NY, S7, __,
				__, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, S0, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, N3, PW, PW, PW, PW, PW, PW, PW, N3, __, __, __,
				__, __, __, M2, M1, NY, __, __, __, __, __, M2, __, __, __,
				__, __, __, X8, {param2 = 3,name = "stairs:slab_pine_wood",prob = 254}, NY, T7, __, __, __, __, X8, __, __, __,
				__, __, __, M2, __, NY, __, __, __, __, __, M2, __, __, __,
				__, __, NX, PW, __, NY, {param2 = 0,name = "stairs:slab_pine_wood",prob = 254}, PW, PW, PW, PW, PW, NX, __, __,
				__, __, M4, __, __, NY, __, __, __, __, __, B2, M4, __, __,
				__, __, X8, __, __, __, __, __, __, __, __, __, X8, __, __,
				__, __, NX, T7, __, __, __, __, __, __, __, T6, NX, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, S8, NY, NY, N9, N9, N9, NY, N9, N9, N9, NY, NY, S6, __,
				S8, S3, M5, M5, M5, M5, M5, M5, M5, M5, M5, M5, M5, S1, S6,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, N3, PW, PW, PW, PW, PW, PW, PW, M1, __, __, __,
				__, __, __, M2, PW, {param2 = 3,name = "stairs:slab_pine_wood",prob = 254}, __, __, __, F0, F0, M2, __, __, __,
				__, __, __, M2, __, __, __, __, __, __, __, M2, __, __, __,
				__, __, __, M2, __, __, __, __, __, __, __, M2, __, __, __,
				__, __, NX, PW, __, {param2 = 23,name = "stairs:stair_pine_wood",prob = 254}, PW, PW, PW, PW, PW, PW, NX, __, __,
				__, __, M4, __, __, II, __, __, __, __, __, C1, M4, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, __, NX, __, __, __, __, __, __, __, __, __, NX, __, __,
				__, __, M4, __, __, __, __, __, __, __, __, __, M4, __, __,
				__, Q2, NY, NY, N9, N9, N9, NY, N9, N9, N9, NY, NY, Q2, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, M1, DD, DD, DD, DD, DD, DD, DD, DD, DD, M1, DD, DD,
				__, __, S1, NY, M1, M1, N3, NY, N3, M1, M1, NY, S3, __, __,
				__, __, __, NY, M2, M2, M2, NY, M2, M2, M2, NY, __, __, __,
				__, __, __, NY, M2, X5, M2, NY, M2, X5, M2, NY, __, __, __,
				__, __, QW, NY, M2, M2, M2, NY, M2, M2, M2, NY, QE, __, __,
				__, __, NZ, PW, PW, PW, PW, PW, PW, PW, PW, PW, NX, __, __,
				__, __, NY, NY, __, II, __, NY, I0, BN, BN, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, I7, NY, NY, __, __,
				__, __, NY, NY, __, __, __, NY, __, __, __, NY, NY, __, __,
				__, Q2, NY, NY, N9, N9, N9, NY, N9, N9, N9, NY, NY, Q2, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, M1, DD, DD, DD, M1, DD, DD, DD, M1, DD, DD, DD,
				__, __, __, S2, __, __, __, S2, __, __, __, S2, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, QS, __, __, __, QS, __, __, __, QS, __, __, __,
				__, __, __, NZ, NZ, NZ, NZ, NZ, NZ, NZ, NZ, NZ, __, __, __,
				__, __, __, NY, M4, M4, M4, NY, M4, M4, M4, NY, __, __, __,
				__, __, __, NY, M4, X5, M4, NY, M4, X5, M4, NY, __, __, __,
				__, Q2, Q2, NY, NZ, NZ, NZ, NY, NZ, NZ, NZ, NY, Q2, Q2, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, S2, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254},
				{ypos = 5,prob = 254},
				{ypos = 6,prob = 254},
				{ypos = 7,prob = 254},
				{ypos = 8,prob = 254},
				{ypos = 9,prob = 254},
				{ypos = 10,prob = 254},
				{ypos = 11,prob = 254},
				{ypos = 12,prob = 254}
			}
		}



		towns_imperial.schem_bldg_village_07_x15_y13_z15_r000 = {
			size = {x = 15,y = 13,z = 15},
			data = {
				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, Q2, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, S1, S6, __, __, __, __, __, S8, S3,
				__, __, __, __, __, __, __, S1, S6, __, __, __, S8, S3, __,
				__, __, __, __, __, __, __, __, S1, S6, __, S8, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, Q2, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, S2, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, S0, __, __, __, S0, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, QN, __, __, __, QN, __, __,
				__, __, __, __, __, __, __, __, NX, NX, NX, NX, NX, __, __,
				__, __, __, __, __, __, __, __, NY, M4, M4, M4, NY, __, __,
				__, __, __, __, __, __, __, __, NY, M4, X5, M4, NY, __, __,
				__, __, __, __, __, __, S1, S6, NY, NZ, NZ, NZ, NY, S8, S3,
				__, __, __, __, __, __, __, S1, NY, M4, M4, M4, NY, S3, __,
				__, __, __, __, __, __, __, __, S1, NY, M4, NY, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, NY, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, M7, __, __, __, __,

				DD, M1, M1, N3, M1, N3, M1, M1, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, S1, NY, M1, N3, M1, NY, S3, __,
				__, __, __, __, __, __, __, __, NY, M2, M2, M2, NY, __, __,
				__, __, __, __, __, __, __, __, NY, M2, X5, M2, NY, __, __,
				__, __, __, __, __, __, __, QW, NY, M2, M2, M2, NY, QE, __,
				__, __, __, __, __, __, __, NZ, PW, PW, PW, PW, PW, NX, __,
				__, __, __, __, __, __, __, NY, NY, __, __, __, NY, NY, __,
				__, __, __, __, __, __, __, NY, NY, __, __, __, NY, NY, __,
				__, __, __, __, __, __, S1, NY, NY, __, T9, __, NY, NY, S3,
				__, __, __, __, __, __, __, S1, NY, __, __, __, NY, S3, __,
				__, __, __, __, __, __, __, __, S1, NY, __, NY, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, NY, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, M7, __, __, __, __,

				DD, M1, N3, M1, N3, M1, N3, M1, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, N3, PW, PW, PW, M1, __, __,
				__, __, __, __, __, __, __, __, M2, __, __, __, M2, __, __,
				__, __, __, __, __, __, __, T6, M2, __, __, __, M2, __, __,
				__, __, __, __, __, __, __, __, M2, __, __, __, M2, __, __,
				__, __, __, __, __, __, __, NX, PW, PW, PW, PW, PW, NZ, __,
				__, __, __, __, __, __, __, M4, __, __, __, __, __, M4, __,
				__, __, __, __, __, __, __, M4, __, __, __, __, __, M4, __,
				__, __, __, __, __, __, S1, NZ, __, __, __, __, __, NZ, S3,
				__, __, __, __, __, __, __, S1, N9, __, __, __, N9, S3, __,
				__, __, __, __, __, __, __, __, S1, N9, __, N9, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, N9, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, M7, __, __, __, __,

				DD, DD, N3, M1, M1, N3, M1, M1, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, {param2 = 1,name = "stairs:stair_cobble",prob = 254}, M1, PW, PW, PW, N3, __, __,
				__, __, __, __, __, __, __, __, D3, __, __, __, M2, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, X8, __, __,
				__, __, __, __, __, __, __, __, M2, __, __, __, M2, __, __,
				__, __, __, __, __, __, __, NX, PW, PW, PW, PW, PW, NZ, __,
				__, __, __, __, __, __, __, M4, __, __, __, __, __, M4, __,
				__, __, __, __, __, __, __, X8, __, __, __, __, __, X8, __,
				__, __, __, __, __, __, S1, NZ, __, __, __, __, __, NZ, S3,
				__, __, __, __, __, __, __, S1, N9, __, __, __, N9, S3, __,
				__, __, __, __, __, __, __, __, S1, N9, __, N9, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, N9, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, M7, __, __, __, __,

				DD, M1, N3, M1, N3, M1, N3, N3, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, M1, PW, PW, PW, M1, __, __,
				__, __, __, __, __, __, __, __, M2, __, __, __, M2, __, __,
				__, __, __, __, __, __, __, T6, M2, __, __, __, M2, __, __,
				__, __, __, __, __, __, __, __, M2, __, __, __, M2, __, __,
				__, __, __, __, __, __, __, NX, PW, PW, PW, PW, PW, NZ, __,
				Q6, Q6, Q6, Q6, Q6, Q6, Q6, M4, __, __, __, __, __, M4, __,
				__, __, __, __, __, __, __, M4, __, __, __, __, __, M4, __,
				__, __, __, __, __, __, S1, NZ, __, __, __, __, __, NZ, S3,
				__, __, __, __, __, __, __, S1, N9, __, __, __, N9, S3, __,
				__, __, __, __, __, __, __, __, S1, N9, __, N9, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, N9, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, M7, __, __, __, __,

				DD, M1, M1, M1, M1, N3, M1, M1, DD, DD, DD, DD, DD, M1, DD,
				NY, __, __, __, __, __, __, S1, NY, PW, PW, PW, NY, S3, __,
				NY, __, __, __, __, __, __, __, NY, __, __, __, NY, __, __,
				NY, __, __, __, __, __, __, __, NY, __, __, __, NY, __, __,
				NY, __, __, __, __, __, __, QW, NY, __, __, __, NY, QE, __,
				NY, __, __, __, __, __, __, NZ, PW, PW, PW, PW, PW, NX, __,
				Q5, Q5, Q5, Q5, Q5, Q5, Q5, NY, NY, __, __, __, NY, NY, __,
				__, __, __, __, __, __, __, NY, NY, __, __, __, NY, NY, __,
				__, __, __, __, __, __, S1, NY, NY, __, __, __, NY, NY, S3,
				__, __, __, __, __, __, __, S1, NY, __, __, __, NY, S3, __,
				__, __, __, __, __, __, __, __, S1, NY, __, NY, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, NY, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, M7, __, __, __, __,

				DD, N3, M1, N3, M1, M1, M1, M1, DD, DD, DD, DD, DD, DD, DD,
				II, __, __, __, __, __, __, __, M1, PW, PW, PW, M1, __, __,
				__, __, __, __, __, __, __, __, M2, __, __, __, M2, __, __,
				__, __, __, __, __, __, __, __, M2, __, T8, __, M2, __, __,
				__, __, __, __, __, __, __, __, M2, {param2 = 22,name = "stairs:slab_pine_wood",prob = 254}, __, __, M2, __, __,
				Q6, Q6, Q6, Q6, Q6, Q6, Q6, NX, PW, __, {param2 = 1,name = "stairs:slab_pine_wood",prob = 254}, PW, PW, NZ, __,
				__, __, __, __, __, __, __, M4, __, __, __, __, __, M4, __,
				__, __, __, __, __, __, __, M4, __, __, __, __, __, M4, __,
				__, __, __, __, __, __, S1, NX, __, __, __, __, __, NZ, S3,
				__, __, __, __, __, __, __, S1, N9, __, __, __, N9, S3, __,
				__, __, __, __, __, __, __, __, S1, N9, __, N9, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, N9, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, M7, __, __, __, __,

				DD, M1, N3, M1, M1, N3, M1, M1, DD, DD, DD, DD, DD, DD, DD,
				II, __, __, __, __, __, __, C1, N3, PW, PW, PW, N3, __, __,
				__, __, __, __, __, __, __, __, M2, N9, NY, {param2 = 0,name = "stairs:slab_pine_wood",prob = 254}, M2, __, __,
				__, __, __, __, __, __, __, __, X8, __, NY, __, X8, __, __,
				__, __, __, __, __, __, __, __, M2, {param2 = 2,name = "stairs:slab_pine_wood",prob = 254}, NY, __, M2, __, __,
				Q5, Q5, Q5, Q5, Q5, Q5, Q5, NX, PW, __, NY, {param2 = 22,name = "stairs:stair_pine_wood",prob = 254}, PW, NZ, __,
				__, __, __, __, __, __, __, M4, __, __, NY, II, II, M4, __,
				__, __, __, __, __, __, __, X8, __, __, __, __, __, X8, __,
				__, __, __, __, __, __, S1, NX, __, __, __, __, __, NZ, S3,
				__, __, __, __, __, __, __, S1, N9, __, __, __, N9, S3, __,
				__, __, __, __, __, __, __, __, S1, N9, __, N9, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, N9, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, M7, __, __, __, __,

				DD, M1, M1, M1, M1, M1, M1, M1, DD, DD, DD, DD, DD, DD, DD,
				II, C0, I0, M1, M1, N3, __, C1, M1, PW, PW, PW, M1, __, __,
				__, __, __, __, __, __, __, __, M2, N9, PW, PW, M2, __, __,
				__, __, __, __, __, __, __, __, M2, PW, {param2 = 3,name = "stairs:slab_pine_wood",prob = 254}, __, M2, __, __,
				Q6, Q6, Q6, Q6, Q6, Q6, Q6, Q6, M2, __, __, __, M2, __, __,
				__, __, __, __, __, __, __, NX, PW, __, __, __, PW, NZ, __,
				__, __, __, __, __, __, __, M4, __, __, __, __, __, M4, __,
				__, __, __, __, __, __, __, M4, __, __, __, __, __, M4, __,
				__, __, __, __, __, __, S1, NX, __, __, __, __, __, NZ, S3,
				__, __, __, __, __, __, __, S1, N9, __, __, __, N9, S3, __,
				__, __, __, __, __, __, __, __, S1, N9, __, N9, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, N9, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, M7, __, __, __, __,

				DD, M1, M1, M1, M1, M1, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				NY, II, II, M1, N3, N3, II, S1, NY, M1, N3, N3, NY, S3, __,
				NY, __, __, M1, F0, M1, __, __, NY, M2, M2, M2, NY, __, __,
				NY, __, __, N3, M1, M1, __, __, NY, M2, X5, M2, NY, __, __,
				Q5, Q5, Q5, M1, M1, M1, Q5, N9, NY, M2, M2, M2, NY, QE, __,
				__, __, __, M1, M1, M1, __, NZ, PW, PW, PW, PW, PW, NX, __,
				__, __, __, M1, M1, {param2 = 3,name = "stairs:stair_cobble",prob = 254}, __, NY, NY, __, __, __, NY, NY, __,
				__, __, __, N3, M1, __, __, NY, NY, __, __, __, NY, NY, __,
				__, __, __, M1, M1, __, S1, NY, NY, __, T8, __, NY, NY, S3,
				__, __, __, M1, M1, __, __, S1, NY, __, __, __, NY, S3, __,
				__, __, __, M1, M1, __, __, __, S1, NY, __, NY, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, NY, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, M7, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, N3, N3, M1, __, __, S2, __, __, __, S2, __, __,
				__, __, __, M1, M1, M1, __, __, __, __, __, __, __, __, __,
				Q6, Q6, Q6, M1, M1, M1, Q6, Q6, Q6, __, __, __, __, __, __,
				__, __, __, M1, M1, N3, __, __, QS, __, __, __, QS, __, __,
				__, __, __, M1, M1, M1, __, __, NZ, NZ, NZ, NZ, NZ, __, __,
				__, __, __, N3, M1, {param2 = 3,name = "stairs:stair_cobble",prob = 254}, __, __, NY, M4, M4, M4, NY, __, __,
				__, __, __, M1, M1, __, __, __, NY, M4, X5, M4, NY, __, __,
				__, __, __, M1, N3, __, S1, S6, NY, NX, NX, NX, NY, S8, S3,
				__, __, __, M1, N3, __, __, S1, NY, M4, M4, M4, NY, S3, __,
				__, __, __, N3, M1, __, __, __, S1, NY, M4, NY, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, NY, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, M7, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, S1, S6, __, __, __, __, __, S8, S3,
				__, __, __, __, __, __, __, S1, S6, __, __, __, S8, S3, __,
				__, __, __, __, __, __, __, __, S1, S6, __, S8, S3, __, __,
				__, __, __, __, __, __, __, __, __, S1, S7, S3, __, __, __,
				__, __, __, __, __, __, __, __, __, __, S0, __, __, __, __,

				DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD, DD,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, __, __, __, __, __,
				__, __, __, __, __, __, __, __, __, __, S7, __, __, __, __
			},
			yslice_prob = {
				{ypos = 0,prob = 254},
				{ypos = 1,prob = 254},
				{ypos = 2,prob = 254},
				{ypos = 3,prob = 254},
				{ypos = 4,prob = 254},
				{ypos = 5,prob = 254},
				{ypos = 6,prob = 254},
				{ypos = 7,prob = 254},
				{ypos = 8,prob = 254},
				{ypos = 9,prob = 254},
				{ypos = 10,prob = 254},
				{ypos = 11,prob = 254},
				{ypos = 12,prob = 254}
			}
		}

