Minetest Game mod: flowers
==========================
See license.txt for license information.

Authors of source code
----------------------
Originally by Ironzorg (MIT) and VanessaE (MIT)
Various Minetest developers and contributors (MIT)

Authors of media (textures)
---------------------------
RHRhino (CC BY-SA 3.0):
  flowers_dandelion_white.png
  flowers_geranium.png
  flowers_rose.png
  flowers_tulip.png
  flowers_viola.png

Gambit (CC BY-SA 3.0):
  flowers_mushroom_brown.png
  flowers_mushroom_red.png
  flowers_waterlily.png

yyt16384 (CC BY-SA 3.0):
  flowers_waterlily_bottom.png -- Derived from Gambit's texture

paramat (CC BY-SA 3.0):
  flowers_dandelion_yellow.png -- Derived from RHRhino's texture
  flowers_tulip_black.png -- Derived from RHRhino's texture
  flowers_chrysanthemum_green.png
