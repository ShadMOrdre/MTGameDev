-- Define perlin noises used in this mapgen by default
lib_mg_params.noises = {}

if lib_mg_params.noise_set_id == 1 then
	-- Noise 1 : Base Ground Height						2D
	--lib_mg_params.noises[1] = {offset = -10, scale = 50, seed = 5202, spread = {x = 1024, y = 1024, z = 1024}, octaves = 6, persist = 0.4, lacunarity = 2},
	lib_mg_params.noises[1] = {offset = -10, scale = 25, seed = 5202, spread = {x = 4096, y = 4096, z = 4096}, octaves = 6, persist = 0.4, lacunarity = 2}
	-- Noise 2 : Valleys (River where around zero)				2D
	lib_mg_params.noises[2] = {offset = 0, scale = 1, seed = -6050, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.6, lacunarity = 2}
	-- Noise 3 : Valleys Depth						2D
	lib_mg_params.noises[3] = {offset = 5, scale = 4, seed = -1914, spread = {x = 512, y = 512, z = 512}, octaves = 1, persist = 1, lacunarity = 2}
	-- Noise 4 : Valleys Profile (Higher values = Larger valleys)		2D
	lib_mg_params.noises[4] = {offset = 0.6, scale = 0.5, seed = 777, spread = {x = 512, y = 512, z = 512}, octaves = 1, persist = 1, lacunarity = 2}
	-- Noise 5 : Inter-valleys slopes					2D
	lib_mg_params.noises[5] = {offset = 0.5, scale = 0.5, seed = 746, spread = {x = 128, y = 128, z = 128}, octaves = 1, persist = 1, lacunarity = 2}
	-- Noise 6 : Inter-valleys filling					3D
	lib_mg_params.noises[6] = {offset = 0, scale = 1, seed = 1993, spread = {x = 256, y = 512, z = 256}, octaves = 6, persist = 0.8, lacunarity = 2}
	-- Noise 7 : Dirt thickness						2D
	lib_mg_params.noises[7] = {offset = 3, scale = 1.75, seed = 1605, spread = {x = 256, y = 256, z = 256}, octaves = 3, persist = 0.5, lacunarity = 2}
	-- Noise 8 : Caves I							3D
	lib_mg_params.noises[8] = {offset = 0, scale = 1, seed = -4640, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 9 : Caves II							3D
	lib_mg_params.noises[9] = {offset = 0, scale = 1, seed = 8804, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 10 : Caves III							3D
	lib_mg_params.noises[10] = {offset = 0, scale = 1, seed = -4780, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 11 : Caves IV and Lava I					3D
	lib_mg_params.noises[11] = {offset = 0, scale = 1, seed = -9969, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 12 : Lava II (Geologic heat)					3D
	lib_mg_params.noises[12] = {offset = 0, scale = 1, seed = 3314, spread = {x = 64, y = 64, z = 64}, octaves = 4, persist = 0.5, lacunarity = 2}

	-- Noise 13 : Clayey dirt noise						2D
	lib_mg_params.noises[13] = {offset = 0, scale = 1, seed = 2835, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.5, lacunarity = 4}
	-- Noise 14 : Silty dirt noise						2D
	lib_mg_params.noises[14] = {offset = 0, scale = 1, seed = 6674, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.5, lacunarity = 4}
	-- Noise 15 : Sandy dirt noise						2D
	lib_mg_params.noises[15] = {offset = 0, scale = 1, seed = 6940, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.5, lacunarity = 4}
	-- Noise 16 : Beaches							2D
	lib_mg_params.noises[16] = {offset = 2, scale = 8, seed = 2349, spread = {x = 256, y = 256, z = 256}, octaves = 3, persist = 0.5, lacunarity = 2}

	-- Noise 17 : Temperature (not in maps)					3D
	lib_mg_params.noises[17] = {offset = 2, scale = 1, seed = -1805, spread = {x = 768, y = 256, z = 768}, octaves = 4, persist = 0.5, lacunarity = 4}
	-- Noise 18 : Humidity							2D
	lib_mg_params.noises[18] = {offset = 0, scale = 1, seed = -5787, spread = {x = 243, y = 243, z = 243}, octaves = 4, persist = 0.5, lacunarity = 3}

	-- Noise 21 : Water plants							2D
	lib_mg_params.noises[21] = {offset = 0.0, scale = 1.0, spread = {x = 200, y = 200, z = 200}, seed = 33, octaves = 3, persist = 0.7, lacunarity = 2.0}
	-- Noise 22 : Cave blend							2D
	lib_mg_params.noises[22] = {offset = 0.0, scale = 0.1, spread = {x = 8, y = 8, z = 8}, seed = 4023, octaves = 2, persist = 1.0, lacunarity = 2.0}
	-- Noise 23 : Cave noise							2D
	lib_mg_params.noises[23] = {offset = 0.0, scale = 1.0, spread = {x = 400, y = 400, z = 400}, seed = 903, octaves = 3, persist = 0.5, lacunarity = 2.0}
end

if lib_mg_params.noise_set_id == 2 then
	-- Noise 1 : Base Ground Height						2D
	--lib_mg_params.noises[1] = {offset = -10, scale = 50, seed = 5202, spread = {x = 1024, y = 1024, z = 1024}, octaves = 6, persist = 0.4, lacunarity = 2},
	lib_mg_params.noises[1] = {offset = -10, scale = 50, seed = 5202, spread = {x = 1024, y = 1024, z = 1024}, octaves = 6, persist = 0.4, lacunarity = 2}
	-- Noise 2 : Valleys (River where around zero)				2D
	lib_mg_params.noises[2] = {offset = 0, scale = 1, seed = -6050, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.6, lacunarity = 2}
	-- Noise 3 : Valleys Depth						2D
	lib_mg_params.noises[3] = {offset = 5, scale = 4, seed = -1914, spread = {x = 512, y = 512, z = 512}, octaves = 1, persist = 1, lacunarity = 2}
	-- Noise 4 : Valleys Profile (Higher values = Larger valleys)		2D
	lib_mg_params.noises[4] = {offset = 0.6, scale = 0.5, seed = 777, spread = {x = 512, y = 512, z = 512}, octaves = 1, persist = 1, lacunarity = 2}
	-- Noise 5 : Inter-valleys slopes					2D
	lib_mg_params.noises[5] = {offset = 0.5, scale = 0.5, seed = 746, spread = {x = 128, y = 128, z = 128}, octaves = 1, persist = 1, lacunarity = 2}
	-- Noise 6 : Inter-valleys filling					3D
	lib_mg_params.noises[6] = {offset = 0, scale = 1, seed = 1993, spread = {x = 256, y = 512, z = 256}, octaves = 6, persist = 0.8, lacunarity = 2}
	-- Noise 7 : Dirt thickness						2D
	lib_mg_params.noises[7] = {offset = 3, scale = 1.75, seed = 1605, spread = {x = 256, y = 256, z = 256}, octaves = 3, persist = 0.5, lacunarity = 2}
	-- Noise 8 : Caves I							3D
	lib_mg_params.noises[8] = {offset = 0, scale = 1, seed = -4640, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 9 : Caves II							3D
	lib_mg_params.noises[9] = {offset = 0, scale = 1, seed = 8804, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 10 : Caves III							3D
	lib_mg_params.noises[10] = {offset = 0, scale = 1, seed = -4780, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 11 : Caves IV and Lava I					3D
	lib_mg_params.noises[11] = {offset = 0, scale = 1, seed = -9969, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 12 : Lava II (Geologic heat)					3D
	lib_mg_params.noises[12] = {offset = 0, scale = 1, seed = 3314, spread = {x = 64, y = 64, z = 64}, octaves = 4, persist = 0.5, lacunarity = 2}

	-- Noise 13 : Clayey dirt noise						2D
	lib_mg_params.noises[13] = {offset = 0, scale = 1, seed = 2835, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.5, lacunarity = 4}
	-- Noise 14 : Silty dirt noise						2D
	lib_mg_params.noises[14] = {offset = 0, scale = 1, seed = 6674, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.5, lacunarity = 4}
	-- Noise 15 : Sandy dirt noise						2D
	lib_mg_params.noises[15] = {offset = 0, scale = 1, seed = 6940, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.5, lacunarity = 4}
	-- Noise 16 : Beaches							2D
	lib_mg_params.noises[16] = {offset = 2, scale = 8, seed = 2349, spread = {x = 256, y = 256, z = 256}, octaves = 3, persist = 0.5, lacunarity = 2}

	-- Noise 17 : Temperature (not in maps)					3D
	lib_mg_params.noises[17] = {offset = 2, scale = 1, seed = -1805, spread = {x = 768, y = 256, z = 768}, octaves = 4, persist = 0.5, lacunarity = 4}
	-- Noise 18 : Humidity							2D
	lib_mg_params.noises[18] = {offset = 0, scale = 1, seed = -5787, spread = {x = 243, y = 243, z = 243}, octaves = 4, persist = 0.5, lacunarity = 3}

	-- Noise 21 : Water plants							2D
	lib_mg_params.noises[21] = {offset = 0.0, scale = 1.0, spread = {x = 200, y = 200, z = 200}, seed = 33, octaves = 3, persist = 0.7, lacunarity = 2.0}
	-- Noise 22 : Cave blend							2D
	lib_mg_params.noises[22] = {offset = 0.0, scale = 0.1, spread = {x = 8, y = 8, z = 8}, seed = 4023, octaves = 2, persist = 1.0, lacunarity = 2.0}
	-- Noise 23 : Cave noise							2D
	lib_mg_params.noises[23] = {offset = 0.0, scale = 1.0, spread = {x = 400, y = 400, z = 400}, seed = 903, octaves = 3, persist = 0.5, lacunarity = 2.0}

end

if lib_mg_params.noise_set_id == 3 then
	-- Noise 1 : Base Ground Height						2D
	--lib_mg_params.noises[1] = {offset = -10, scale = 50, seed = 5202, spread = {x = 1024, y = 1024, z = 1024}, octaves = 6, persist = 0.4, lacunarity = 2},
	lib_mg_params.noises[1] = {offset = -10, scale = 25, seed = 5202, spread = {x = 4096, y = 8192, z = 4096}, octaves = 6, persist = 0.4, lacunarity = 2}
	-- Noise 2 : Valleys (River where around zero)				2D
	lib_mg_params.noises[2] = {offset = 0, scale = 1, seed = -6050, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.6, lacunarity = 2}
	-- Noise 3 : Valleys Depth						2D
	lib_mg_params.noises[3] = {offset = 5, scale = 4, seed = -1914, spread = {x = 512, y = 512, z = 512}, octaves = 1, persist = 1, lacunarity = 2}
	-- Noise 4 : Valleys Profile (Higher values = Larger valleys)		2D
	lib_mg_params.noises[4] = {offset = 0.6, scale = 0.5, seed = 777, spread = {x = 512, y = 512, z = 512}, octaves = 1, persist = 1, lacunarity = 2}
	-- Noise 5 : Inter-valleys slopes					2D
	lib_mg_params.noises[5] = {offset = 0.5, scale = 0.5, seed = 746, spread = {x = 128, y = 128, z = 128}, octaves = 1, persist = 1, lacunarity = 2}
	-- Noise 6 : Inter-valleys filling					3D
	lib_mg_params.noises[6] = {offset = 0, scale = 1, seed = 1993, spread = {x = 256, y = 512, z = 256}, octaves = 6, persist = 0.8, lacunarity = 2}
	-- Noise 7 : Dirt thickness						2D
	lib_mg_params.noises[7] = {offset = 3, scale = 1.75, seed = 1605, spread = {x = 256, y = 256, z = 256}, octaves = 3, persist = 0.5, lacunarity = 2}
	-- Noise 8 : Caves I							3D
	lib_mg_params.noises[8] = {offset = 0, scale = 1, seed = -4640, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 9 : Caves II							3D
	lib_mg_params.noises[9] = {offset = 0, scale = 1, seed = 8804, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 10 : Caves III							3D
	lib_mg_params.noises[10] = {offset = 0, scale = 1, seed = -4780, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 11 : Caves IV and Lava I					3D
	lib_mg_params.noises[11] = {offset = 0, scale = 1, seed = -9969, spread = {x = 32, y = 32, z = 32}, octaves = 4, persist = 0.5, lacunarity = 2}
	-- Noise 12 : Lava II (Geologic heat)					3D
	lib_mg_params.noises[12] = {offset = 0, scale = 1, seed = 3314, spread = {x = 64, y = 64, z = 64}, octaves = 4, persist = 0.5, lacunarity = 2}

	-- Noise 13 : Clayey dirt noise						2D
	lib_mg_params.noises[13] = {offset = 0, scale = 1, seed = 2835, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.5, lacunarity = 4}
	-- Noise 14 : Silty dirt noise						2D
	lib_mg_params.noises[14] = {offset = 0, scale = 1, seed = 6674, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.5, lacunarity = 4}
	-- Noise 15 : Sandy dirt noise						2D
	lib_mg_params.noises[15] = {offset = 0, scale = 1, seed = 6940, spread = {x = 256, y = 256, z = 256}, octaves = 5, persist = 0.5, lacunarity = 4}
	-- Noise 16 : Beaches							2D
	lib_mg_params.noises[16] = {offset = 2, scale = 8, seed = 2349, spread = {x = 256, y = 256, z = 256}, octaves = 3, persist = 0.5, lacunarity = 2}

	-- Noise 17 : Temperature (not in maps)					3D
	lib_mg_params.noises[17] = {offset = 2, scale = 1, seed = -1805, spread = {x = 768, y = 256, z = 768}, octaves = 4, persist = 0.5, lacunarity = 4}
	-- Noise 18 : Humidity							2D
	lib_mg_params.noises[18] = {offset = 0, scale = 1, seed = -5787, spread = {x = 243, y = 243, z = 243}, octaves = 4, persist = 0.5, lacunarity = 3}

	-- Noise 21 : Water plants							2D
	lib_mg_params.noises[21] = {offset = 0.0, scale = 1.0, spread = {x = 200, y = 200, z = 200}, seed = 33, octaves = 3, persist = 0.7, lacunarity = 2.0}
	-- Noise 22 : Cave blend							2D
	lib_mg_params.noises[22] = {offset = 0.0, scale = 0.1, spread = {x = 8, y = 8, z = 8}, seed = 4023, octaves = 2, persist = 1.0, lacunarity = 2.0}
	-- Noise 23 : Cave noise							2D
	lib_mg_params.noises[23] = {offset = 0.0, scale = 1.0, spread = {x = 400, y = 400, z = 400}, seed = 903, octaves = 3, persist = 0.5, lacunarity = 2.0}

end



