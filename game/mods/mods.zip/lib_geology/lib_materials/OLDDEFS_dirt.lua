
local S = lib_materials.gettext

--Additional Dirts


--Default Dirt with Grass



--30biomes Mud
minetest.register_node("lib_materials:mud_01", {
	description = "Mud 01 (30biomes)",
	tiles = {"biomes_mud.png",},
	is_ground_content = true,
	groups = {crumbly=3},
	drop = 'lib_materials:mud_lump 4',
	sounds = default.node_sound_dirt_defaults({footstep = "",}),
})



--Darkage Dirts

minetest.register_node("lib_materials:dirt_dark", {
	description = "Dark Dirt",
	tiles = {"darkage_darkdirt.png"},
	is_ground_content = false,
	groups = {crumbly=2, not_cuttable=1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node("lib_materials:silt_01", {
	description = "Silt",
	tiles = {"darkage_silt.png"},
	is_ground_content = true,
	groups = {crumbly=3},
	drop = 'lib_materials:silt_lump 4',
	sounds = default.node_sound_dirt_defaults({
		footstep = "",
	}),
})






-- Mapgen Dirts

minetest.register_node("lib_materials:dirt_coarse", {
	description = "Coarse Dirt",
	tiles = {"mapgen_coarse_dirt.png"},
	groups = {crumbly = 3, dig_immediate=3},
	sounds = default.node_sound_dirt_defaults()
})

minetest.register_node("lib_materials:dirt_dry", {
	description = "Dry Dirt",
	tiles = {"mapgen_dry_dirt.png"},
	groups = {crumbly = 3},
	sounds = default.node_sound_dirt_defaults()
})




--Valleys_c Dirts

-- Valleys_c silt and red clay.

-- Add silt
minetest.register_node("lib_materials:silt_02", {
	description = "Silt (mg_valleys)",
	tiles = {"vmg_silt.png"},
	is_ground_content = true,
	groups = {crumbly=3},
	sounds = default.node_sound_dirt_defaults(),
})

-- I don't like the default:clay, this does not look like clay. So add red clay.
minetest.register_node("lib_materials:clay_red", {
	description = "Red Clay",
	tiles = {"vmg_red_clay.png"},
	is_ground_content = true,
	groups = {crumbly=3},
	sounds = default.node_sound_dirt_defaults(),
})
-- 3 types of dirt :
-- Clayey dirt is a dirt that contains clay, but is not pure clay
-- Idem for silty dirt that contains silt without beeing pure silt
-- And sandy dirt







-- -- local function register_clays()
	-- -- local itemstr_dirt = "lib_materials:clay_red"
	-- -- local itemstr_lawn = itemstr_dirt .. "_with_grass"
	-- -- local itemstr_lawn2 = itemstr_dirt .. "_with_grass2"
	-- -- local itemstr_lawn3 = itemstr_dirt .. "_with_grass3"
	-- -- local itemstr_lawn4 = itemstr_dirt .. "_with_grass4"
	-- -- local itemstr_lawn5 = itemstr_dirt .. "_with_grass5"
	-- -- local itemstr_brown = itemstr_dirt .. "_with_brown_grass"
	-- -- local itemstr_dry = itemstr_dirt .. "_with_dry_grass"
	-- -- local itemstr_dry2 = itemstr_dirt .. "_with_dry_grass2"
	-- -- local itemstr_dry3 = itemstr_dirt .. "_with_dry_grass3"
	-- -- local itemstr_dry4 = itemstr_dirt .. "_with_dry_grass4"
	-- -- local itemstr_dry5 = itemstr_dirt .. "_with_dry_grass5"
	-- -- local itemstr_dry9 = itemstr_dirt .. "_with_dry_grass9"
	-- -- local itemstr_rain = itemstr_dirt .. "_with_rainforest_litter"
	-- -- local itemstr_coniferous = itemstr_dirt .. "_with_coniferous_litter"
	-- -- local itemstr_snow = itemstr_dirt .. "_with_snow"
	-- -- local tilestr = "lib_materials_clay_red.png"


	-- -- minetest.register_node(itemstr_lawn, {
		-- -- description = "Red Clay with Grass",
		-- -- tiles = {"default_grass.png", tilestr, tilestr .. "^default_grass_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn2, {
		-- -- description = "Red Clay with Grass2",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#69e942:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#69e942:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn3, {
		-- -- description = "Clay with Grass3",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#b1e436:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#b1e436:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn4, {
		-- -- description = "Clay with Grass4",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#dacf61:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#dacf61:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn5, {
		-- -- description = "Clay with Grass5",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#fcd953:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#fcd953:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_brown, {
		-- -- description = "Clay with Brown Grass",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#e8bb30:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#e8bb30:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_rain, {
		-- -- description = "Red Clay with Rainforest Litter",
		-- -- tiles = {"default_rainforest_litter.png", tilestr, tilestr .. "^default_rainforest_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_coniferous, {
		-- -- description = "Red Clay with Coniferous Litter",
		-- -- tiles = {"default_coniferous_litter.png", tilestr, tilestr .. "^default_coniferous_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry, {
		-- -- description = "Red Clay with Dry Grass",
		-- -- tiles = {"default_dry_grass.png", tilestr, tilestr .. "^default_dry_grass_side.png"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry2, {
		-- -- description = "Red Clay with Dry Grass2",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#ace943:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#ace943:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry3, {
		-- -- description = "Red Clay with Dry Grass3",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#e4d136:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#e4d136:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry4, {
		-- -- description = "Red Clay with Dry Grass4",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#daa062:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#daa062:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry5, {
		-- -- description = "Red Clay with Dry Grass5",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#fc9754:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#fc9754:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry9, {
		-- -- description = "Red Clay with Dry Grass9",
		-- -- tiles = {"lib_materials_dry_grass.png^[colorize:#fc9754:80", tilestr, tilestr .. "^(lib_materials_dry_grass_side.png^[colorize:#fc9754:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_snow, {
		-- -- description = "Red Clay with Snow",
		-- -- tiles = {"default_snow.png", tilestr, tilestr .. "^default_snow_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_snow_footstep", gain=0.25},
		-- -- }),
	-- -- })

-- -- end


-- -- local function register_muds()
	-- -- local itemstr_dirt = "lib_materials:mud_01"
	-- -- local itemstr_lawn = itemstr_dirt .. "_with_grass"
	-- -- local itemstr_lawn2 = itemstr_dirt .. "_with_grass2"
	-- -- local itemstr_lawn3 = itemstr_dirt .. "_with_grass3"
	-- -- local itemstr_brown = itemstr_dirt .. "_with_brown_grass"
	-- -- local itemstr_dry = itemstr_dirt .. "_with_dry_grass"
	-- -- local itemstr_dry2 = itemstr_dirt .. "_with_dry_grass2"
	-- -- local itemstr_dry3 = itemstr_dirt .. "_with_dry_grass3"
	-- -- local itemstr_rain = itemstr_dirt .. "_with_rainforest_litter"
	-- -- local itemstr_coniferous = itemstr_dirt .. "_with_coniferous_litter"
	-- -- local itemstr_snow = itemstr_dirt .. "_with_snow"
	-- -- local tilestr = "lib_materials_mud_01.png"


	-- -- minetest.register_node(itemstr_lawn, {
		-- -- description = "Mud 01 with Grass",
		-- -- tiles = {"default_grass.png", tilestr, tilestr .. "^default_grass_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn2, {
		-- -- description = "Mud 01 with Grass2",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#69e942:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#69e942:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn3, {
		-- -- description = "Mud 01 with Grass3",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#b1e436:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#b1e436:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_brown, {
		-- -- description = "Mud 01 with Brown Grass",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#e8bb30:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#e8bb30:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_rain, {
		-- -- description = "Mud 01 with Rainforest Litter",
		-- -- tiles = {"default_rainforest_litter.png", tilestr, tilestr .. "^default_rainforest_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_coniferous, {
		-- -- description = "Mud 01 with Coniferous Litter",
		-- -- tiles = {"default_coniferous_litter.png", tilestr, tilestr .. "^default_coniferous_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry, {
		-- -- description = "Mud 01 with Dry Grass",
		-- -- tiles = {"default_dry_grass.png", tilestr, tilestr .. "^default_dry_grass_side.png"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry2, {
		-- -- description = "Mud 01 with Dry Grass2",
		-- -- tiles = {"lib_materials_dry_grass.png^[colorize:#ace943:80", tilestr, tilestr .. "^(lib_materials_dry_grass_side.png^[colorize:#ace943:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry3, {
		-- -- description = "Mud 01 with Dry Grass3",
		-- -- tiles = {"lib_materials_dry_grass.png^[colorize:#e4d136:80", tilestr, tilestr .. "^(lib_materials_dry_grass_side.png^[colorize:#e4d136:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_snow, {
		-- -- description = "Mud 01 with Snow",
		-- -- tiles = {"default_snow.png", tilestr, tilestr .. "^default_snow_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_snow_footstep", gain=0.25},
		-- -- }),
	-- -- })

-- -- end

-- -- local function register_silts()
	-- -- local itemstr_dirt = "lib_materials:silt_02"
	-- -- local itemstr_lawn = itemstr_dirt .. "_with_grass"
	-- -- local itemstr_lawn2 = itemstr_dirt .. "_with_grass2"
	-- -- local itemstr_lawn3 = itemstr_dirt .. "_with_grass3"
	-- -- local itemstr_brown = itemstr_dirt .. "_with_brown_grass"
	-- -- local itemstr_brown5 = itemstr_dirt .. "_with_brown_grass5"
	-- -- local itemstr_dry = itemstr_dirt .. "_with_dry_grass"
	-- -- local itemstr_dry2 = itemstr_dirt .. "_with_dry_grass2"
	-- -- local itemstr_dry3 = itemstr_dirt .. "_with_dry_grass3"
	-- -- local itemstr_rain = itemstr_dirt .. "_with_rainforest_litter"
	-- -- local itemstr_coniferous = itemstr_dirt .. "_with_coniferous_litter"
	-- -- local itemstr_snow = itemstr_dirt .. "_with_snow"
	-- -- local tilestr = "lib_materials_silt_02.png"


	-- -- minetest.register_node(itemstr_lawn, {
		-- -- description = "Silt 02 with Grass",
		-- -- tiles = {"default_grass.png", tilestr, tilestr .. "^default_grass_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn2, {
		-- -- description = "Silt 02 with Grass2",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#69e942:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#69e942:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn3, {
		-- -- description = "Silt 02 with Grass3",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#b1e436:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#b1e436:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_brown, {
		-- -- description = "Silt 02 with Brown Grass",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#e8bb30:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#e8bb30:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_brown5, {
		-- -- description = "Silt 02 with Brown Grass5",
		-- -- tiles = {"lib_materials_grass.png^[colorize:#fc5458:80", tilestr, tilestr .. "^(lib_materials_grass_side.png^[colorize:#fc5458:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_rain, {
		-- -- description = "Silt 02 with Rainforest Litter",
		-- -- tiles = {"default_rainforest_litter.png", tilestr, tilestr .. "^default_rainforest_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_coniferous, {
		-- -- description = "Silt 02 with Coniferous Litter",
		-- -- tiles = {"default_coniferous_litter.png", tilestr, tilestr .. "^default_coniferous_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry, {
		-- -- description = "Silt 02 with Dry Grass",
		-- -- tiles = {"default_dry_grass.png", tilestr, tilestr .. "^default_dry_grass_side.png"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry2, {
		-- -- description = "Silt 02 with Dry Grass2",
		-- -- tiles = {"lib_materials_dry_grass.png^[colorize:#ace943:80", tilestr, tilestr .. "^(lib_materials_dry_grass_side.png^[colorize:#ace943:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry3, {
		-- -- description = "Silt 02 with Dry Grass3",
		-- -- tiles = {"lib_materials_dry_grass.png^[colorize:#e4d136:80", tilestr, tilestr .. "^(lib_materials_dry_grass_side.png^[colorize:#e4d136:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_snow, {
		-- -- description = "Silt 02 with Snow",
		-- -- tiles = {"default_snow.png", tilestr, tilestr .. "^default_snow_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_snow_footstep", gain=0.25},
		-- -- }),
	-- -- })

-- -- end



-- -- register_clays()
-- -- register_muds()
-- -- register_silts()





-- -- local function register_course_dirts(readname)
	-- -- local name = readname:lower()
	-- -- local itemstr_dirt = "lib_materials:dirt_" .. name
	-- -- local itemstr_lawn = itemstr_dirt .. "_with_grass"
	-- -- local itemstr_lawn2 = itemstr_dirt .. "_with_grass2"
	-- -- local itemstr_lawn3 = itemstr_dirt .. "_with_grass3"
	-- -- local itemstr_brown = itemstr_dirt .. "_with_brown_grass"
	-- -- local itemstr_dry = itemstr_dirt .. "_with_dry_grass"
	-- -- local itemstr_dry2 = itemstr_dirt .. "_with_dry_grass2"
	-- -- local itemstr_dry3 = itemstr_dirt .. "_with_dry_grass3"
	-- -- local itemstr_rain = itemstr_dirt .. "_with_rainforest_litter"
	-- -- local itemstr_coniferous = itemstr_dirt .. "_with_coniferous_litter"
	-- -- local itemstr_snow = itemstr_dirt .. "_with_snow"
	-- -- local tilestr = "mapgen_coarse_dirt.png"


	-- -- minetest.register_node(itemstr_lawn, {
		-- -- description = readname .. " Dirt with Grass",
		-- -- tiles = {"default_grass.png", tilestr, tilestr .. "^default_grass_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn2, {
		-- -- description = readname .. " Dirt with Grass2",
		-- -- tiles = {"default_grass.png^[colorize:#69e942:80", tilestr, tilestr .. "^(default_grass_side.png^[colorize:#69e942:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn3, {
		-- -- description = readname .. " Dirt with Grass3",
		-- -- tiles = {"default_grass.png^[colorize:#FFFF00:80", tilestr, tilestr .. "^(default_grass_side.png^[colorize:#FFFF00:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_brown, {
		-- -- description = readname .. " Dirt with Brown Grass",
		-- -- tiles = {"luscious_grass.png^[colorize:#e8bb30:80", tilestr, tilestr .. "^mg_dry_grass_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_rain, {
		-- -- description = readname .. " Dirt with Rainforest Litter",
		-- -- tiles = {"default_rainforest_litter.png", tilestr, tilestr .. "^default_rainforest_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_coniferous, {
		-- -- description = readname .. " Dirt with Coniferous Litter",
		-- -- tiles = {"default_coniferous_litter.png", tilestr, tilestr .. "^default_coniferous_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry, {
		-- -- description = readname .. " Dirt with Dry Grass",
		-- -- tiles = {"default_dry_grass.png", tilestr, tilestr .. "^default_dry_grass_side.png"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry2, {
		-- -- description = readname .. " Dirt with Dry Grass2",
		-- -- tiles = {"default_dry_grass.png^[colorize:#ace943:80", tilestr, tilestr .. "^(default_dry_grass_side.png^[colorize:#ace943:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry3, {
		-- -- description = readname .. " Dirt with Dry Grass3",
		-- -- tiles = {"default_dry_grass.png^[colorize:#FFFF00:80", tilestr, tilestr .. "^(default_dry_grass_side.png^[colorize:#FFFF00:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_snow, {
		-- -- description = readname .. " Dirt with Snow",
		-- -- tiles = {"default_snow.png", tilestr, tilestr .. "^default_snow_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_snow_footstep", gain=0.25},
		-- -- }),
	-- -- })

-- -- end

-- -- local function register_dark_dirts(readname)
	-- -- local name = readname:lower()
	-- -- local itemstr_dirt = "lib_materials:dirt_" .. name
	-- -- local itemstr_lawn = itemstr_dirt .. "_with_grass"
	-- -- local itemstr_lawn2 = itemstr_dirt .. "_with_grass2"
	-- -- local itemstr_lawn3 = itemstr_dirt .. "_with_grass3"
	-- -- local itemstr_brown = itemstr_dirt .. "_with_brown_grass"
	-- -- local itemstr_dry = itemstr_dirt .. "_with_dry_grass"
	-- -- local itemstr_dry2 = itemstr_dirt .. "_with_dry_grass2"
	-- -- local itemstr_dry3 = itemstr_dirt .. "_with_dry_grass3"
	-- -- local itemstr_rain = itemstr_dirt .. "_with_rainforest_litter"
	-- -- local itemstr_coniferous = itemstr_dirt .. "_with_coniferous_litter"
	-- -- local itemstr_snow = itemstr_dirt .. "_with_snow"
	-- -- local tilestr = "darkage_darkdirt.png"


	-- -- minetest.register_node(itemstr_lawn, {
		-- -- description = readname .. " Dirt with Grass",
		-- -- tiles = {"default_grass.png", tilestr, tilestr .. "^default_grass_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn2, {
		-- -- description = readname .. " Dirt with Grass2",
		-- -- tiles = {"default_grass.png^[colorize:#69e942:80", tilestr, tilestr .. "^(default_grass_side.png^[colorize:#69e942:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn3, {
		-- -- description = readname .. " Dirt with Grass3",
		-- -- tiles = {"default_grass.png^[colorize:#FFFF00:80", tilestr, tilestr .. "^(default_grass_side.png^[colorize:#FFFF00:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_brown, {
		-- -- description = readname .. " Dirt with Brown Grass",
		-- -- tiles = {"luscious_grass.png^[colorize:#e8bb30:80", tilestr, tilestr .. "^mg_dry_grass_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_rain, {
		-- -- description = readname .. " Dirt with Rainforest Litter",
		-- -- tiles = {"default_rainforest_litter.png", tilestr, tilestr .. "^default_rainforest_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_coniferous, {
		-- -- description = readname .. " Dirt with Coniferous Litter",
		-- -- tiles = {"default_coniferous_litter.png", tilestr, tilestr .. "^default_coniferous_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry, {
		-- -- description = readname .. " Dirt with Dry Grass",
		-- -- tiles = {"default_dry_grass.png", tilestr, tilestr .. "^default_dry_grass_side.png"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry2, {
		-- -- description = readname .. " Dirt with Dry Grass2",
		-- -- tiles = {"default_dry_grass.png^[colorize:#ace943:80", tilestr, tilestr .. "^(default_dry_grass_side.png^[colorize:#ace943:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry3, {
		-- -- description = readname .. " Dirt with Dry Grass3",
		-- -- tiles = {"default_dry_grass.png^[colorize:#FFFF00:80", tilestr, tilestr .. "^(default_dry_grass_side.png^[colorize:#FFFF00:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_snow, {
		-- -- description = readname .. " Dirt with Snow",
		-- -- tiles = {"default_snow.png", tilestr, tilestr .. "^default_snow_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_snow_footstep", gain=0.25},
		-- -- }),
	-- -- })

-- -- end

-- -- local function register_dry_dirts(readname)
	-- -- local name = readname:lower()
	-- -- local itemstr_dirt = "lib_materials:dirt_" .. name
	-- -- local itemstr_lawn = itemstr_dirt .. "_with_grass"
	-- -- local itemstr_lawn2 = itemstr_dirt .. "_with_grass2"
	-- -- local itemstr_lawn3 = itemstr_dirt .. "_with_grass3"
	-- -- local itemstr_brown = itemstr_dirt .. "_with_brown_grass"
	-- -- local itemstr_dry = itemstr_dirt .. "_with_dry_grass"
	-- -- local itemstr_dry2 = itemstr_dirt .. "_with_dry_grass2"
	-- -- local itemstr_dry3 = itemstr_dirt .. "_with_dry_grass3"
	-- -- local itemstr_rain = itemstr_dirt .. "_with_rainforest_litter"
	-- -- local itemstr_coniferous = itemstr_dirt .. "_with_coniferous_litter"
	-- -- local itemstr_snow = itemstr_dirt .. "_with_snow"
	-- -- local tilestr = "mapgen_dry_dirt.png"


	-- -- minetest.register_node(itemstr_lawn, {
		-- -- description = readname .. " Dirt with Grass",
		-- -- tiles = {"default_grass.png", tilestr, tilestr .. "^default_grass_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn2, {
		-- -- description = readname .. " Dirt with Grass2",
		-- -- tiles = {"default_grass.png^[colorize:#69e942:80", tilestr, tilestr .. "^(default_grass_side.png^[colorize:#69e942:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_lawn3, {
		-- -- description = readname .. " Dirt with Grass3",
		-- -- tiles = {"default_grass.png^[colorize:#FFFF00:80", tilestr, tilestr .. "^(default_grass_side.png^[colorize:#FFFF00:80)"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_brown, {
		-- -- description = readname .. " Dirt with Brown Grass",
		-- -- tiles = {"luscious_grass.png^[colorize:#e8bb30:80", tilestr, tilestr .. "^mg_dry_grass_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_rain, {
		-- -- description = readname .. " Dirt with Rainforest Litter",
		-- -- tiles = {"default_rainforest_litter.png", tilestr, tilestr .. "^default_rainforest_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_coniferous, {
		-- -- description = readname .. " Dirt with Coniferous Litter",
		-- -- tiles = {"default_coniferous_litter.png", tilestr, tilestr .. "^default_coniferous_litter_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_grass_footstep", gain=0.25},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry, {
		-- -- description = readname .. " Dirt with Dry Grass",
		-- -- tiles = {"default_dry_grass.png", tilestr, tilestr .. "^default_dry_grass_side.png"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry2, {
		-- -- description = readname .. " Dirt with Dry Grass2",
		-- -- tiles = {"default_dry_grass.png^[colorize:#ace943:80", tilestr, tilestr .. "^(default_dry_grass_side.png^[colorize:#ace943:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_dry3, {
		-- -- description = readname .. " Dirt with Dry Grass3",
		-- -- tiles = {"default_dry_grass.png^[colorize:#FFFF00:80", tilestr, tilestr .. "^(default_dry_grass_side.png^[colorize:#FFFF00:80)"},
		-- -- groups = {crumbly=3, soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name = "default_grass_footstep", gain=0.4},
		-- -- }),
	-- -- })

	-- -- minetest.register_node(itemstr_snow, {
		-- -- description = readname .. " Dirt with Snow",
		-- -- tiles = {"default_snow.png", tilestr, tilestr .. "^default_snow_side.png"},
		-- -- is_ground_content = true,
		-- -- groups = {crumbly=3,soil=1},
		-- -- drop = itemstr_dirt,
		-- -- sounds = default.node_sound_dirt_defaults({
			-- -- footstep = {name="default_snow_footstep", gain=0.25},
		-- -- }),
	-- -- })

-- -- end





--register_course_dirts("Course")
--register_dark_dirts("Dark")
--register_dry_dirts("Dry")

