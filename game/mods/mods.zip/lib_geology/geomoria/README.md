# geomoria

This mod uses a simple table-based description of an underground region to create huge, geomorphic constructions. My goal is to make it look a bit like Tolkien's Moria.


![screenshot](https://raw.githubusercontent.com/duane-r/geomoria/master/screenshot1.jpg)


The source is available on github.

Code: LGPL2

Mod dependencies: default

Download: https://github.com/duane-r/geomoria/archive/master.zip
